from sympy import isprime
from math import gcd
import random
import pymysql
from pymysql import Error


class GestionRSA:
    """
    Gère :
      - la génération des clés RSA
      - le stockage des clés privées en mémoire
      - l’enregistrement des clés publiques dans MySQL
      - le chargement des clés publiques depuis MySQL
      - la configuration réseau (ports routeurs / clients)
    """

    def __init__(self):
        # Configuration réseau
        self.config_reseau = {
            "routers": {
                "R1": {"port": 5001},
                "R2": {"port": 5002},
                "R3": {"port": 5003},
                "R4": {"port": 5004}
            },
            "clients": {
                "C1": {"port": 4001},
                "C2": {"port": 4002}
            }
        }

        # Configuration BD
        self.config_bd = {
            "host": "localhost",
            "user": "root",     # adapte si besoin
            "password": "toto",
            "database": "SAE302",
            "charset": "utf8mb4"
        }

        # Clés privées en mémoire : { "R1": {"d":..., "n":...}, ... }
        self.cles_privees = {}

    # ============================
    # Connexion / BD
    # ============================

    def creer_base_et_table(self):
        """Crée la base SAE302 et la table routeurs si besoin, puis vide la table routeurs."""
        try:
            conn = pymysql.connect(
                host=self.config_bd["host"],
                user=self.config_bd["user"],
                password=self.config_bd["password"],
                charset=self.config_bd["charset"]
            )
            cur = conn.cursor()
            cur.execute(f"CREATE DATABASE IF NOT EXISTS {self.config_bd['database']}")
            conn.commit()
            cur.close()
            conn.close()
        except Error as e:
            print(f"[BD] Erreur creation base: {e}")
            return

        try:
            conn = pymysql.connect(**self.config_bd)
            cur = conn.cursor()
            # Création de la table si besoin
            cur.execute("""
            CREATE TABLE IF NOT EXISTS routeurs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nom VARCHAR(20) NOT NULL UNIQUE,
                ip VARCHAR(15) NOT NULL,
                port INT NOT NULL,
                cle_publique VARCHAR(256) NOT NULL
            )
            """)
            conn.commit()

            # FLUSH : vider toutes les lignes de la table
            #cur.execute("DELETE FROM routeurs")
            #conn.commit()
            #print("[BD] Base + table 'routeurs' OK, contenu vidé")

            cur.close()
            conn.close()
        except Error as e:
            print(f"[BD] Erreur creation/flush table: {e}")

    def enregistrer_cle_publique(self, nom_routeur: str, n: int):
        """Enregistre / met à jour la clé publique (n) du routeur dans la BD."""


        try:
            conn = pymysql.connect(
                host=self.config_bd["host"],
                user=self.config_bd["user"],
                password=self.config_bd["password"],
                database=self.config_bd["database"],
                charset=self.config_bd["charset"]
            )
            cur = conn.cursor()
            ip = "127.0.0.1"
            port = self.config_reseau["routers"][nom_routeur]["port"]

            sql = (
                "INSERT INTO routeurs (ip, nom, port, cle_publique) "
                "VALUES (%s, %s, %s, %s) "
                "ON DUPLICATE KEY UPDATE "
                "ip = VALUES(ip), "
                "port = VALUES(port), "
                "cle_publique = VALUES(cle_publique)"
            )

            # n est déjà un entier, on l’envoie tel quel
            cur.execute(sql, (ip, nom_routeur, port, n))
            conn.commit()
            cur.close()
            conn.close()
            print(f"[BD] Clé publique de {nom_routeur} enregistrée")
        except Exception as e:
            print(f"[BD] Erreur enregistrer_cle_publique({nom_routeur}) : {e}")

    def charger_cles_publiques_depuis_bd(self) -> dict:
        """
        Charge toutes les clés publiques depuis la BD.
        Retourne un dict { 'R1': (e, n), ... } avec e = 65537.
        """
        cles = {}
        try:
            conn = pymysql.connect(**self.config_bd)
            cur = conn.cursor()
            cur.execute("SELECT nom, cle_publique FROM routeurs")
            for nom, n in cur.fetchall():
                cles[nom] = (65537, int(n))
            cur.close()
            conn.close()
        except Error as e:
            print(f"[BD] Erreur charger_cles_publiques_depuis_bd: {e}")
        return cles

    # ============================
    # Utilitaires RSA
    # ============================

    def generer_premier(self, bits=256) -> int:
        """Génère un nombre premier aléatoire de 'bits' bits."""
        while True:
            p = random.getrandbits(bits)
            if p % 2 == 0:
                p += 1
            if isprime(p):
                return p

    def egcd(self, a: int, b: int):
        if a == 0:
            return b, 0, 1
        g, y, x = self.egcd(b % a, a)
        return g, x - (b // a) * y, y

    def inverse_modulaire(self, a: int, m: int) -> int:
        g, x, _ = self.egcd(a, m)
        if g != 1:
            raise Exception("Pas d'inverse modulaire")
        return x % m

    def generer_cles_rsa(self, bits=256):
        p = self.generer_premier(bits)
        q = self.generer_premier(bits)
        while q == p:
            q = self.generer_premier(bits)
        n = p * q
        phi = (p - 1) * (q - 1)

        e = 65537
        if phi % e == 0:
            e = 3
            while phi % e == 0:
                e += 2

        d = self.inverse_modulaire(e, phi)
        return (e, n), (d, n)

    def generer_toutes_les_cles(self, bits=125):
        """Génère les clés pour R1..R4, stocke les privées en mémoire et les publiques en BD."""
        self.creer_base_et_table()  # s'assure que SAE302.routeurs existe

        noms_routeurs = ["R1", "R2", "R3", "R4"]
        for nom in noms_routeurs:
            print(f"[*] Génération clés {nom}...")
            (e, n), (d, _) = self.generer_cles_rsa(bits=bits)


            # stocker la clé privée en mémoire
            self.cles_privees[nom] = {"d": d, "n": n}

            # enregistrer n en base
            self.enregistrer_cle_publique(nom, n)

            print(f"[OK] {nom} : clés générées (mémoire + BD)")

    # ============================
    # Accès aux clés privées
    # ============================

    def obtenir_cle_privee(self, nom_routeur: str) -> "RSAKey":
        if nom_routeur not in self.cles_privees:
            raise ValueError(f"Clé privée manquante pour {nom_routeur}")
        d = self.cles_privees[nom_routeur]["d"]
        n = self.cles_privees[nom_routeur]["n"]
        return RSAKey(e=0, d=d, n=n)


class RSAKey:
    """RSA : texte <-> entier, via ord/chr (octets 0-255), sans UTF-8."""

    def __init__(self, e: int, d: int, n: int):
        self.e = e
        self.d = d
        self.n = n

    def _texte_vers_entier(self, message: str) -> int:
        """Texte -> codes ord(c) -> entier big-endian."""
        M = 0
        for ch in message:
            b = ord(ch) & 0xFF  # on garde 0-255
            M = (M << 8) | b
        return M

    def _entier_vers_texte(self, M: int) -> str:
        """Entier big-endian -> octets -> texte via chr()."""
        if M == 0:
            return ""
        octets = []
        while M > 0:
            octets.append(M & 0xFF)
            M >>= 8
        octets.reverse()
        return "".join(chr(b) for b in octets)

    def chiffrer_texte(self, message: str) -> int:
        """Chiffre un texte en un entier C."""
        M = self._texte_vers_entier(message)
        if M >= self.n:
            raise ValueError("Message trop long pour ce n (pas de découpe en blocs).")
        return pow(M, self.e, self.n)

    def dechiffrer_entier(self, C: int) -> str:
        """Déchiffre un entier C et retourne le texte clair."""
        M = pow(C, self.d, self.n)
        return self._entier_vers_texte(M)



