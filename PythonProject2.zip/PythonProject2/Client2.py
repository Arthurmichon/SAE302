import socket
import threading
import sys

from rsa_outils import GestionRSA, RSAKey

IP = "127.0.0.1"

gestion = GestionRSA()
port_client = gestion.config_reseau["clients"]["C2"]["port"]

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
sock.bind((IP, port_client))
sock.listen()


def recevoir():
    while True:
        conn, _ = sock.accept()
        with conn:
            donnees = conn.recv(65536)
            if not donnees:
                continue
            msg = donnees.decode()
            sys.stdout.write('\r' + ' ' * 80 + '\r')
            print(f"\n>>> Message reçu : {msg}")
            sys.stdout.write("Route (ex: R1,R3,R2) : ")
            sys.stdout.flush()


threading.Thread(target=recevoir, daemon=True).start()

print(f"[C2] démarré sur le port {port_client}\n")

cles_publiques = gestion.charger_cles_publiques_depuis_bd()
print(f"[C2] Clés publiques chargées depuis la BD : {list(cles_publiques.keys())}\n")


def construire_paquet(route, destinataire, liste_entiers):
    # route1;route2;...|dest|v1,v2,v3,...
    route_texte = ";".join(route)
    donnees_texte = ",".join(str(x) for x in liste_entiers)
    return route_texte + "|" + destinataire + "|" + donnees_texte


while True:
    route_saisie = input("\nRoute (ex: R1,R3,R2) : ")
    route = [r.strip() for r in route_saisie.split(",") if r.strip()]
    if not route:
        continue

    message = input("Message : ")
    destinataire = "C1"

    texte_courant = message

    # *** OIGNON RSA ***
    for r in reversed(route):
        if r not in cles_publiques:
            print(f"Erreur : routeur {r} introuvable dans la BD")
            texte_courant = None
            break
        e, n = cles_publiques[r]
        cle_pub = RSAKey(e=e, d=0, n=n)
        C = cle_pub.chiffrer_texte(texte_courant)
        texte_courant = str(C)  # pour la couche suivante

    if texte_courant is None:
        continue

    # ENVOI : route|dest|C (un seul entier, pas de liste!)
    route_texte = ";".join(route)
    donnees_texte = texte_courant  # déjà un str(int)
    paquet_texte = route_texte + "|" + destinataire + "|" + donnees_texte

    premier_port = gestion.config_reseau["routers"][route[0]]["port"]
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((IP, premier_port))
            s.sendall(paquet_texte.encode())
        print(f"[C2] Message envoyé via route {' -> '.join(route)}\n")
    except Exception as e:
        print(f"[C2] ERREUR connexion {route[0]} : {e}\n")
