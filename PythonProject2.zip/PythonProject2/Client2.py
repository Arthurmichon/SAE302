import socket
import threading
from rsa_outils import GestionCryptoSQL, MiniRSAKey

IP_ROUTEUR = "127.0.0.1"
ROUTEUR_PRINCIPAL = "R1"
PORT_ROUTEUR = 5001  # Port fixe du routeur principal

# ===============================
# Initialisation client
# ===============================

nom_client = "C2"
port_client = int(input(f"Entrez le port du client {nom_client} : "))

# ===============================
# Initialisation Crypto
# ===============================

g = GestionCryptoSQL()
cles_pub = g.charger_cles_publiques()  # Toutes les clés publiques

# ===============================
# Enregistrement auprès du routeur
# ===============================

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((IP_ROUTEUR, PORT_ROUTEUR))
    s.sendall(f"CLIENT|{nom_client}|{port_client}".encode())
print(f"[{nom_client}] Port envoyé à {ROUTEUR_PRINCIPAL}")

# ===============================
# Fonction pour recevoir les messages
# ===============================

def recevoir_messages():
    serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    serveur.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    serveur.bind(("127.0.0.1", port_client))
    serveur.listen()
    print(f"[{nom_client}] En écoute sur le port {port_client}...\n")
    while True:
        conn, _ = serveur.accept()
        with conn:
            data = conn.recv(65536)
            if data:
                print(f"\n[{nom_client}] Message reçu : {data.decode()}\n> ", end="")

threading.Thread(target=recevoir_messages, daemon=True).start()

# ===============================
# Boucle envoi de messages
# ===============================

while True:
    route = input("Route (ex: R1,R3,R2) : ").strip()
    message = input("Message : ").strip()

    texte_courant = message
    for r in route.split(","):
        cle_pub = cles_pub[r]
        texte_courant = str(cle_pub.chiffrer(texte_courant))  # Chiffre pour chaque routeur

    paquet = ";".join(route.split(",")) + f"|C1|{texte_courant}"

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((IP_ROUTEUR, PORT_ROUTEUR))
        s.sendall(paquet.encode())
