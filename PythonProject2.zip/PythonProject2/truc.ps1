# ============================================
# Script PowerShell - Lance tous les fichiers
# ============================================
# Ce script lance :
# 1. Les 4 routeurs (R1, R2, R3, R4) dans des terminaux separes
# 2. Les 2 clients (Client1, Client2) dans des terminaux separes
# ============================================
# ============================================
# INSTALLATION AUTOMATIQUE DES LIBRAIRIES PYTHON
# ============================================

Write-Host "Verification / installation des librairies Python (sympy, pymysql)..."

# Utilise le python par defaut
$python = "python"

# Fonction utilitaire pour installer un package si besoin
function Ensure-Package {
    param(
        [string]$PackageName
    )
    Write-Host "  -> $PackageName" -NoNewline

    $checkCmd = "$python -m pip show $PackageName"
    $installed = Invoke-Expression $checkCmd 2>$null

    if (-not $installed) {
        Write-Host " (installation en cours...)"
        $installCmd = "$python -m pip install $PackageName"
        Invoke-Expression $installCmd
    } else {
        Write-Host " (deja installe)"
    }
}

Ensure-Package "sympy"
Ensure-Package "pymysql"

Write-Host "Librairies verifiees."
# Repertoire du projet
$PROJECT_DIR = "C:\Users\e2400457\PycharmProjects\PythonProject2"
Set-Location $PROJECT_DIR

Write-Host "========================================"
Write-Host "Demarrage du systeme de routage RSA"
Write-Host "========================================"
Write-Host ""

# ============================================
# DEMARRAGE DES ROUTEURS
# ============================================

Write-Host "[1/6] Demarrage du Routeur R1..."
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PROJECT_DIR'; python R1.py R1"
Start-Sleep -Seconds 2

Write-Host "[2/6] Demarrage du Routeur R2..."
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PROJECT_DIR'; python R1.py R2"
Start-Sleep -Seconds 2

Write-Host "[3/6] Demarrage du Routeur R3..."
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PROJECT_DIR'; python R1.py R3"
Start-Sleep -Seconds 2

Write-Host "[4/6] Demarrage du Routeur R4..."
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PROJECT_DIR'; python R1.py R4"
Start-Sleep -Seconds 2

# ============================================
# DEMARRAGE DES CLIENTS
# ============================================

Write-Host "[5/6] Demarrage du Client 1..."
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PROJECT_DIR'; python Client1.py"
Start-Sleep -Seconds 2

Write-Host "[6/6] Demarrage du Client 2..."
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PROJECT_DIR'; python Client2.py"
Start-Sleep -Seconds 2

# ============================================
# MESSAGE FINAL
# ============================================

Write-Host ""
Write-Host "========================================"
Write-Host "SUCCES - Tous les processus ont ete lances !"
Write-Host "========================================"
Write-Host ""
Write-Host "Les terminaux sont maintenant ouverts :"
Write-Host "  Terminal 1 : Routeur R1 (port 5001)"
Write-Host "  Terminal 2 : Routeur R2 (port 5002)"
Write-Host "  Terminal 3 : Routeur R3 (port 5003)"
Write-Host "  Terminal 4 : Routeur R4 (port 5004)"
Write-Host "  Terminal 5 : Client 1 (port 4001)"
Write-Host "  Terminal 6 : Client 2 (port 4002)"
Write-Host ""
Write-Host "Pour envoyer un message :"
Write-Host "  1. Allez dans le terminal Client 1 ou Client 2"
Write-Host "  2. Entrez une route (ex: R1,R2,R3)"
Write-Host "  3. Entrez un message"
Write-Host ""
Write-Host "Le message traversera tous les routeurs cryptes !"
Write-Host ""
