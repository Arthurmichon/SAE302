import socket
import sys
import threading

from rsa_outils import GestionRSA, RSAKey

IP = "127.0.0.1"

# ============================
# Initialisation RSA / Routeur
# ============================

gestion = GestionRSA()
print("[*] Génération des clés RSA (tous routeurs)...")
gestion.generer_toutes_les_cles(bits=125)
print("[OK] Clés générées\n")

# Nom du routeur joué par CE process
nom_routeur = sys.argv[1] if len(sys.argv) > 1 else "R1"
port = gestion.config_reseau["routers"][nom_routeur]["port"]

# Clé privée de CE routeur
cle_privee = gestion.obtenir_cle_privee(nom_routeur)

# Publication / mise à jour de la clé publique de CE routeur dans la BD
n_pub = cle_privee.n
gestion.enregistrer_cle_publique(nom_routeur, n_pub)

# ============================
# Socket serveur
# ============================

serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
serveur.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
serveur.bind((IP, port))
serveur.listen()

print(f"[{nom_routeur}] démarré sur le port {port}...\n")


# ============================
# Format des paquets
# ============================
# route1;route2;...|destinataire|C
# C = entier chiffré RSA (représenté en texte)
# ============================

def parser_paquet(texte: str):
    """
    Format : route1;route2;...|destinataire|C
    où C est un entier (chiffre RSA) en texte.
    Retourne (liste_route, destinataire, C)
    """
    parties = texte.split("|", 3)
    if len(parties) != 3:
        raise ValueError("Paquet invalide")

    route_texte, dest_texte, donnees_texte = parties

    if route_texte.strip():
        liste_route = [r for r in route_texte.split(";") if r]
    else:
        liste_route = []

    destinataire = dest_texte.strip()

    donnees_texte = donnees_texte.strip()
    if donnees_texte:
        try:
            C = int(donnees_texte)
        except ValueError:
            # si ce n'est pas un entier, on ne peut pas continuer
            raise ValueError(f"C non entier dans le paquet : {donnees_texte}")
    else:
        C = 0

    # LOG DEBUG pour voir ce que le routeur reçoit
    print(f"[{nom_routeur}] Paquet reçu : route={liste_route}, dest={destinataire}, C={C}")

    return liste_route, destinataire, C


def construire_paquet(liste_route, destinataire, C: int) -> str:
    """
    Fait l'inverse de parser_paquet.
    """
    route_texte = ";".join(liste_route)
    donnees_texte = str(C)
    return route_texte + "|" + destinataire + "|" + donnees_texte


# ============================
# Gestion d'une connexion
# ============================

def gerer_connexion(connexion):
    with connexion:
        try:
            donnees = connexion.recv(65536)
            if not donnees:
                return
            texte = donnees.decode()
            liste_route, destinataire, C_chiffre = parser_paquet(texte)
            print(f"[{nom_routeur}] Paquet reçu : route={liste_route}, dest={destinataire}, C={C_chiffre}")
        except Exception as e:
            print(f"[{nom_routeur}] Erreur lecture paquet: {e}")
            return

        print(f"[{nom_routeur}] C_chiffre reçu = {C_chiffre}")
        texte_dechiffre = cle_privee.dechiffrer_entier(C_chiffre)
        print(f"[{nom_routeur}] Après déchiffrement : '{texte_dechiffre}'")

        if len(liste_route) == 1:
            # Dernier routeur → texte_dechiffre est le message clair
            message_final = texte_dechiffre
            try:
                port_dest = gestion.config_reseau["clients"][destinataire]["port"]
            except KeyError:
                print(f"[{nom_routeur}] Erreur : client inconnu {destinataire}")
                return
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((IP, port_dest))
                s.sendall(message_final.encode())
            print(f"[{nom_routeur}] Message envoyé au client final ({destinataire}) : {message_final}\n")
        else:
            # Routeur intermédiaire : forward du nouvel entier RSA brut
            prochaine_route = liste_route[1:]
            prochain_routeur = prochaine_route[0]
            # la couche suivante attend un entier codé en str()
            C_suivant = int(texte_dechiffre.strip())
            paquet_texte = construire_paquet(prochaine_route, destinataire, C_suivant)

            port_suivant = gestion.config_reseau["routers"][prochain_routeur]["port"]
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((IP, port_suivant))
                s.sendall(paquet_texte.encode())
            print(f"[{nom_routeur}] Transmis → {prochain_routeur}\n")


# ============================
# Boucle principale
# ============================

while True:
    conn, addr = serveur.accept()
    threading.Thread(target=gerer_connexion, args=(conn,), daemon=True).start()
