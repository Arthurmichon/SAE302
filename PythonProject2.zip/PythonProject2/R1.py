import socket
import sys
import threading

from rsa_outils import GestionRSA

IP = "127.0.0.1"

# Initialisation globale RSA (génère les clés une fois)
gestion = GestionRSA()
print("[*] Génération des clés RSA (tous routeurs)...")
gestion.generer_toutes_les_cles(bits=125)
print("[OK] Clés générées\n")

nom_routeur = sys.argv[1] if len(sys.argv) > 1 else "R1"
port = gestion.config_reseau["routers"][nom_routeur]["port"]

cle_privee = gestion.obtenir_cle_privee(nom_routeur)

serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
serveur.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
serveur.bind((IP, port))
serveur.listen()

print(f"[{nom_routeur}] démarré sur le port {port}...\n")


def parser_paquet(texte):
    """
    Format attendu :
      route1;route2;...|destinataire|v1,v2,v3,...
    Retourne (liste_route, destinataire, liste_entiers)
    """
    parties = texte.split("|", 3)
    if len(parties) != 3:
        raise ValueError("Paquet invalide")

    route_texte, dest_texte, donnees_texte = parties

    if route_texte.strip():
        liste_route = [r for r in route_texte.split(";") if r]
    else:
        liste_route = []

    destinataire = dest_texte

    donnees_texte = donnees_texte.strip()
    if donnees_texte:
        liste_entiers = [int(x) for x in donnees_texte.split(",") if x]
    else:
        liste_entiers = []

    return liste_route, destinataire, liste_entiers


def construire_paquet(liste_route, destinataire, liste_entiers):
    """
    Fait l'inverse de parser_paquet.
    """
    route_texte = ";".join(liste_route)
    donnees_texte = ",".join(str(x) for x in liste_entiers)
    return route_texte + "|" + destinataire + "|" + donnees_texte


def gerer_connexion(connexion):
    with connexion:
        try:
            donnees = connexion.recv(65536)
            if not donnees:
                return
            texte = donnees.decode()
            liste_route, destinataire, donnees_chiffrees = parser_paquet(texte)
        except Exception as e:
            print(f"[{nom_routeur}] Erreur lecture paquet: {e}")
            return

        texte_dechiffre = cle_privee.dechiffrer(donnees_chiffrees)
        print(f"[{nom_routeur}] Après déchiffrement : {texte_dechiffre}")

        if len(liste_route) == 1:
            # Dernier routeur → envoi au client final
            port_dest = gestion.config_reseau["clients"][destinataire]["port"]
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((IP, port_dest))
                s.sendall(texte_dechiffre.encode())
            print(f"[{nom_routeur}] Message envoyé au client final ({destinataire})\n")
        else:
            # On enlève ce routeur de la route et on transmet au suivant
            prochaine_route = liste_route[1:]
            prochain_routeur = prochaine_route[0]

            # On re-transforme le texte déchiffré en liste d'entiers pour le prochain hop
            nouvelle_liste_entiers = [ord(c) for c in texte_dechiffre]
            paquet_texte = construire_paquet(prochaine_route, destinataire, nouvelle_liste_entiers)

            port_suivant = gestion.config_reseau["routers"][prochain_routeur]["port"]
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((IP, port_suivant))
                s.sendall(paquet_texte.encode())
            print(f"[{nom_routeur}] Transmis → {prochain_routeur}\n")


while True:
    conn, addr = serveur.accept()
    threading.Thread(target=gerer_connexion, args=(conn,), daemon=True).start()
