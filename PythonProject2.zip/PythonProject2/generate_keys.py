#!/usr/bin/env python3
"""
generate_keys.py
Génère les clés RSA pour R1..R4, les stocke en mémoire (via GestionRSA)
et enregistre les clés publiques dans la base SAE302.table routeurs.

Ce script est optionnel : les clés peuvent aussi être générées
au démarrage des routeurs via GestionRSA.generer_toutes_les_cles().
"""

from rsa_outils import GestionRSA

if __name__ == "__main__":
    gestion = GestionRSA()

    print("=" * 60)
    print("GENERATION DES CLES RSA (R1..R4)")
    print("=" * 60 + "\n")

    gestion.generer_toutes_les_cles(bits=125)

    print("\n" + "=" * 60)
    print("CLES PRIVEES EN MEMOIRE")
    print("=" * 60)
    for nom, k in gestion.cles_privees.items():
        print(f"\n[{nom}]")
        print(f"  d = {k['d']}")
        print(f"  n = {k['n']}")

    print("\n" + "=" * 60)
    print("CLES PUBLIQUES EN BASE (table routeurs)")
    print("=" * 60)
    cles_pub = gestion.charger_cles_publiques_depuis_bd()
    for nom, (e, n) in cles_pub.items():
        print(f"\n[{nom}]")
        print(f"  e = {e}")
        print(f"  n = {n}")

    print("\n" + "=" * 60)
    print("[✓] Génération terminée (mémoire + base de données)")
    print("=" * 60 + "\n")
