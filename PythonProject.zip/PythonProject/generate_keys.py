import random
from sympy import isprime
import json
import os
import pymysql

# Liste des routeurs
ROUTEURS = ["R1", "R2", "R3", "R4"]
PORTS = {"R1": 5001, "R2": 5002, "R3": 5003, "R4": 5004}


# Générer un nombre premier de taille bits
def generate_prime(bits=256):
    while True:
        p = random.getrandbits(bits)
        if p % 2 == 0:
            p += 1
        if isprime(p):
            return p


# Inverse modulaire
def egcd(a, b):
    if a == 0:
        return b, 0, 1
    g, y, x = egcd(b % a, a)
    return g, x - (b // a) * y, y


def modinv(a, m):
    g, x, _ = egcd(a, m)
    if g != 1:
        raise Exception("Pas d’inverse modulaire")
    return x % m


# Générer clés RSA
def generate_rsa_keys(bits=256):
    p = generate_prime(bits)
    q = generate_prime(bits)
    while q == p:
        q = generate_prime(bits)
    n = p * q
    phi = (p - 1) * (q - 1)
    e = 65537
    d = modinv(e, phi)
    return (e, n), (d, n)


# Connexion MySQL
db = pymysql.connect(
    host="localhost",
    user="sae_user",
    password="toto",
    database="sae302",
    charset = "utf8mb4"
)
cursor = db.cursor()
os.makedirs("keys", exist_ok=True)

for routeur in ROUTEURS:
    print(f"[*] Génération clés {routeur}...")
    public_key, private_key = generate_rsa_keys(bits=125)  # clé plus grande
    e, n = public_key
    d, n_priv = private_key

    # Sauvegarde clé privée
    with open(f"keys/{routeur}_private.json", "w") as f:
        json.dump({"routeur": routeur, "d": d, "n": n}, f, indent=4)

    # Sauvegarde clé publique dans DB
    public_data = json.dumps({"e": e, "n": n})
    sql = """INSERT INTO routeurs (nom, ip, port, cle_publique)
             VALUES (%s,%s,%s,%s)
             ON DUPLICATE KEY UPDATE cle_publique=VALUES(cle_publique)"""
    cursor.execute(sql, (routeur, "127.0.0.1", PORTS[routeur], public_data))
    db.commit()
    print(f"[OK] Clés {routeur} générées.")
