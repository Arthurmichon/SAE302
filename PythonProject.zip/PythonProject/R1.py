import socket
import json
import sys

IP = "127.0.0.1"

# Charger la config
with open("router_config.json", "r") as f:
    CONFIG = json.load(f)

# Nom du routeur passé en argument
ROUTER_NAME = sys.argv[1]
PORT = CONFIG["routers"][ROUTER_NAME]["port"]

# Fonction de déchiffrement (César simple)
def dechiffrement(msg):
    return "".join(chr(ord(c) - 1) for c in msg)

# Création socket
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((IP, PORT))

print(f"{ROUTER_NAME} démarré sur port {PORT}...")

while True:
    data, addr = sock.recvfrom(4096)
    packet = data.decode()

    # Découper le paquet en ROUTE, DEST, DATA
    try:
        parts = packet.split(";")
        route_str = parts[0].split("=")[1]
        dest = parts[1].split("=")[1]
        data_str = parts[2].split("=")[1]
    except IndexError:
        print(f"[{ROUTER_NAME}] Paquet mal formé : {packet}")
        continue

    route_list = route_str.split(",") if route_str else []

    print(f"[{ROUTER_NAME}] Reçu : route={route_list}, data={data_str}")

    # Déchiffrement d'une couche
    data_str = dechiffrement(data_str)
    print(f"[{ROUTER_NAME}] Après déchiffrement : {data_str}")

    if len(route_list) == 1:
        # Dernier routeur → envoyer au client final
        dest_port = CONFIG["clients"][dest]["port"]
        sock.sendto(data_str.encode(), (IP, dest_port))
        print(f"[{ROUTER_NAME}] Message envoyé au client final ({dest})")
    else:
        # Envoyer au prochain routeur
        next_route_list = route_list[1:]        # Retirer ce routeur
        next_router = next_route_list[0]        # Prochain routeur
        new_route_str = ",".join(next_route_list)
        new_packet = f"ROUTE={new_route_str};DEST={dest};DATA={data_str}"
        next_port = CONFIG["routers"][next_router]["port"]
        sock.sendto(new_packet.encode(), (IP, next_port))
        print(f"[{ROUTER_NAME}] Transmis → {next_router}")
