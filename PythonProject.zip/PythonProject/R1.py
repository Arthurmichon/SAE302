import socket
import sys
import json
import threading
from rsa_outils import RSAKey
from pathlib import Path

IP = "127.0.0.1"

ROUTER_NAME = sys.argv[1]

# Charger config
with open("router_config.json", "r") as f:
    CONFIG = json.load(f)

PORT = CONFIG["routers"][ROUTER_NAME]["port"]

# Connexion DB
import pymysql
db = pymysql.connect(
    host="localhost",
    user="root",
    password="toto",
    database="SAE302",
    charset="utf8mb4"
)

# Charger RSA
rsa = RSAKey(ROUTER_NAME,private_path=f"keys/{ROUTER_NAME}_private.json", db_conn=db)

# TCP server
server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_sock.bind((IP, PORT))
server_sock.listen()
print(f"[{ROUTER_NAME}] démarré sur port {PORT}...")

def handle_conn(conn):
    """Gère une connexion entrante"""
    with conn:
        try:
            data = conn.recv(65536)
            if not data:
                return
            packet = json.loads(data.decode())
        except Exception as e:
            print(f"[{ROUTER_NAME}] Erreur lecture packet: {e}")
            return

        route_list = packet["route"]
        dest = packet["dest"]
        encrypted_data = packet["data"]

        # Déchiffrement RSA via la classe
        decrypted_bytes = rsa.decrypt(encrypted_data)
        data_str = ''.join(chr(b) for b in decrypted_bytes)
        print(f"[{ROUTER_NAME}] Après déchiffrement : {data_str}")

        if len(route_list) == 1:
            # Dernier routeur → envoyer au client final
            dest_port = CONFIG["clients"][dest]["port"]
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((IP, dest_port))
                s.sendall(data_str.encode())
                print(f"[{ROUTER_NAME}] Message envoyé au client final ({dest})")
        else:
            # Envoyer au prochain routeur
            next_route_list = route_list[1:]
            next_router = next_route_list[0]
            new_packet = {
                "route": next_route_list,
                "dest": dest,
                "data": decrypted_bytes  # on renvoie sous forme de bytes
            }
            next_port = CONFIG["routers"][next_router]["port"]
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((IP, next_port))
                s.sendall(json.dumps(new_packet).encode())
                print(f"[{ROUTER_NAME}] Transmis → {next_router}")

# Boucle principale
while True:
    conn, addr = server_sock.accept()
    threading.Thread(target=handle_conn, args=(conn,), daemon=True).start()
