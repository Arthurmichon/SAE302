"""
Fichier Router : R1.py

Plus bas il y a les fichiers : Client1.py et Client2.py
"""
import socket
import json
import sys
import os
from rsa_outils import rsa_decrypt_message

IP = "127.0.0.1"

# --------------------------
# Charger config JSON
# --------------------------
with open("router_config.json", "r") as f:
    CONFIG = json.load(f)

ROUTER_NAME = sys.argv[1]
PORT = CONFIG["routers"][ROUTER_NAME]["port"]

# --------------------------
# Charger clé privée
# --------------------------
key_file = f"keys/{ROUTER_NAME}_private.json"
if not os.path.exists(key_file):
    print(f"ERREUR : clé privée introuvable pour {ROUTER_NAME}")
    exit()

with open(key_file, "r") as f:
    priv = json.load(f)

d = priv["d"]
n = priv["n"]

# --------------------------
# Socket
# --------------------------
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((IP, PORT))

print(f"[{ROUTER_NAME}] démarré sur port {PORT}")


while True:

    data, addr = sock.recvfrom(10000)
    packet = json.loads(data.decode())

    route = packet["route"]
    dest = packet["dest"]
    encrypted_blocks = packet["data"]

    print(f"\n[{ROUTER_NAME}] Paquet reçu. Route restante = {route}")

    # --------------------------
    # Déchiffrement de la couche RSA
    # --------------------------
    decrypted = rsa_decrypt_message(encrypted_blocks, d, n)
    print(f"[{ROUTER_NAME}] Contenu après déchiffrage : {decrypted}")

    # Mise à jour du paquet
    if len(route) == 1:
        # Dernier routeur -> envoyer au client final
        dest_port = CONFIG["clients"][dest]["port"]
        sock.sendto(decrypted.encode(), (IP, dest_port))
        print(f"[{ROUTER_NAME}] Message délivré au client final {dest}")
    else:
        # Routeur suivant
        next_route = route[1:]
        next_router = next_route[0]
        next_port = CONFIG["routers"][next_router]["port"]

        new_packet = {
            "route": next_route,
            "dest": dest,
            "data": json.loads(decrypted)  # le message redevient la couche suivante
        }

        sock.sendto(json.dumps(new_packet).encode(), (IP, next_port))
        print(f"[{ROUTER_NAME}] Transmission vers {next_router}")


"""
Fichier client 1 : Client1.py
"""
import socket
import json
import pymysql
from rsa_outils import rsa_encrypt_message
import threading
import sys

IP = "127.0.0.1"

# Charger la config
with open("router_config.json","r") as f:
    CONFIG = json.load(f)

PORT_CLIENT = CONFIG["clients"]["C1"]["port"]
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((IP, PORT_CLIENT))

# ---------------------------
# Connexion DB
# ---------------------------
db = pymysql.connect(
    host="localhost",
    user="root",
    password="toto",
    database="SAE302",
    charset = "utf8mb4"
)
cursor = db.cursor()

# Charge toutes les clés publiques des routeurs
def load_public_keys():
    cursor.execute("SELECT nom, cle_publique FROM routeurs")
    keys = {}
    for nom, cle_json in cursor.fetchall():
        data = json.loads(cle_json)
        keys[nom] = (data["e"], data["n"])
    return keys

public_keys = load_public_keys()

# ---------------------------
# Réception côté client
# ---------------------------


def recevoir():
    while True:
        data, _ = sock.recvfrom(10000)
        msg = data.decode()
        # Effacer la ligne actuelle de l'input et afficher le message
        sys.stdout.write('\r' + ' ' * 80 + '\r')  # efface la ligne courante
        print(f"\n>>> Message reçu : {msg}")
        # Réaffiche le prompt
        sys.stdout.write("Route (ex: R1,R3,R2) : ")
        sys.stdout.flush()



threading.Thread(target=recevoir, daemon=True).start()

# ---------------------------
# Envoi
# ---------------------------
while True:
    route_input = input("\nRoute (ex: R1,R3,R2) : ")
    route = route_input.split(",")
    msg = input("Message : ")

    dest = "C2"

    # Onion : chiffrer du dernier router -> premier
    encrypted = msg
    for r in reversed(route):
        e, n = public_keys[r]
        encrypted = rsa_encrypt_message(json.dumps(encrypted), e, n)

    # Préparer paquet
    packet = {
        "route": route,
        "dest": dest,
        "data": encrypted
    }

    first_port = CONFIG["routers"][route[0]]["port"]
    sock.sendto(json.dumps(packet).encode(), (IP, first_port))



"""
Fichier client 2 : Client2.py
"""
import socket
import json
import pymysql
from rsa_outils import rsa_encrypt_message
import threading
import sys

IP = "127.0.0.1"

# Charger la config
with open("router_config.json","r") as f:
    CONFIG = json.load(f)

PORT_CLIENT = CONFIG["clients"]["C2"]["port"]
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((IP, PORT_CLIENT))

# ---------------------------
# Connexion DB
# ---------------------------
db = pymysql.connect(
    host="localhost",
    user="root",
    password="toto",
    database="SAE302",
    charset = "utf8mb4"
)
cursor = db.cursor()

# Charge toutes les clés publiques des routeurs
def load_public_keys():
    cursor.execute("SELECT nom, cle_publique FROM routeurs")
    keys = {}
    for nom, cle_json in cursor.fetchall():
        data = json.loads(cle_json)
        keys[nom] = (data["e"], data["n"])
    return keys

public_keys = load_public_keys()

# ---------------------------
# Réception côté client
# ---------------------------
def recevoir():
    while True:
        data, _ = sock.recvfrom(10000)
        msg = data.decode()
        # Effacer la ligne actuelle de l'input et afficher le message
        sys.stdout.write('\r' + ' ' * 80 + '\r')  # efface la ligne courante
        print(f"\n>>> Message reçu : {msg}")
        # Réaffiche le prompt
        sys.stdout.write("Route (ex: R1,R3,R2) : ")
        sys.stdout.flush()


threading.Thread(target=recevoir, daemon=True).start()

# ---------------------------
# Envoi
# ---------------------------
while True:
    route_input = input("\nRoute (ex: R1,R3,R2) : ")
    route = route_input.split(",")
    msg = input("Message : ")

    dest = "C1"

    # Onion : chiffrer du dernier router -> premier
    encrypted = msg
    for r in reversed(route):
        e, n = public_keys[r]
        encrypted = rsa_encrypt_message(json.dumps(encrypted), e, n)

    # Préparer paquet
    packet = {
        "route": route,
        "dest": dest,
        "data": encrypted
    }

    first_port = CONFIG["routers"][route[0]]["port"]
    sock.sendto(json.dumps(packet).encode(), (IP, first_port))
