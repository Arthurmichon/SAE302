"""
Fichier Router : R1.py

Plus bas il y a les fichiers : Client1.py et Client2.py
"""

import socket
import json
import sys

IP = "127.0.0.1"

with open("router_config.json", "r") as f:
    CONFIG = json.load(f)

ROUTER_NAME = sys.argv[1]
PORT = CONFIG["routers"][ROUTER_NAME]["port"]

def dechiffrement(msg):
    return "".join(chr(ord(c) - 1) for c in msg)

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((IP, PORT))

print(f"{ROUTER_NAME} démarré sur port {PORT}...")

while True:
    data, addr = sock.recvfrom(4096)
    packet = data.decode()

    # Découper le paquet
    parts = packet.split(";")
    route_str = parts[0].split("=")[1]
    dest = parts[1].split("=")[1]
    data_str = parts[2].split("=")[1]

    route_list = route_str.split(",") if route_str else []

    print(f"[{ROUTER_NAME}] Reçu : route={route_list}, data={data_str}")

    # Déchiffrement d'une couche
    data_str = dechiffrement(data_str)
    print(f"[{ROUTER_NAME}] Après déchiffrement : {data_str}")

    if len(route_list) == 1:
        # Dernier routeur → envoyer au client final
        dest_port = CONFIG["clients"][dest]["port"]
        sock.sendto(data_str.encode(), (IP, dest_port))
        print(f"[{ROUTER_NAME}] Message envoyé au client final")
    else:
        # Envoyer au prochain routeur
        next_router = route_list[1]  # 1 car route_list[0] = ce routeur
        next_route_list = route_list[1:]
        new_route_str = ",".join(next_route_list)
        new_packet = f"ROUTE={new_route_str};DEST={dest};DATA={data_str}"
        next_port = CONFIG["routers"][next_router]["port"]
        sock.sendto(new_packet.encode(), (IP, next_port))
        print(f"[{ROUTER_NAME}] Transmis → {next_router}")

"""
Fichier client 1 : Client1.py
"""
import socket
import json

IP = "127.0.0.1"

# Charger la config
with open("router_config.json", "r") as f:
    CONFIG = json.load(f)

PORT_CLIENT = CONFIG["clients"]["C1"]["port"]

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((IP, PORT_CLIENT))

def chiffrement(msg):
    return "".join(chr(ord(c) + 1) for c in msg)


def recevoir():
    while True:
        data, _ = sock.recvfrom(4096)
        msg = data.decode()
        print(f"\n[Client1] : {msg}")  # Affiche le message reçu
        print("Choisis la route (ex: R1,R3,R2) : ", end="", flush=True)  # Réaffiche le prompt sans sauter de ligne


import threading
threading.Thread(target=recevoir, daemon=True).start()

while True:
    route_input = input("Choisis la route (ex: R1,R3,R2) : ")
    route = route_input.split(",")
    msg = input("Message :  ")  # prompt classique


    # Chiffrer pour chaque routeur, **dans l'ordre inverse**
    data_str = msg
    for _ in reversed(route):
        data_str = chiffrement(data_str)

    # Construire le paquet avec DEST
    dest = "C2"
    route_str = ",".join(route)
    packet = f"ROUTE={route_str};DEST={dest};DATA={data_str}"

    # Envoyer au premier routeur
    first_router_port = CONFIG["routers"][route[0]]["port"]
    sock.sendto(packet.encode(), (IP, first_router_port))


"""
Fichier client 2 : Client2.py
"""
import socket
import json

IP = "127.0.0.1"

# Charger la config
with open("router_config.json", "r") as f:
    CONFIG = json.load(f)

PORT_CLIENT = CONFIG["clients"]["C2"]["port"]

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((IP, PORT_CLIENT))

def chiffrement(msg):
    return "".join(chr(ord(c) + 1) for c in msg)

def recevoir():
    while True:
        data, _ = sock.recvfrom(4096)
        msg = data.decode()
        print(f"\n[Client1] : {msg}")  # Affiche le message reçu
        print("Choisis la route (ex: R1,R3,R2) : ", end="", flush=True)  # Réaffiche le prompt sans sauter de ligne

import threading
threading.Thread(target=recevoir, daemon=True).start()

while True:
    route_input = input("Choisis la route (ex: R1,R3,R2) : ")
    route = route_input.split(",")
    msg = input("Message : ")

    # Chiffrer pour chaque routeur, **dans l'ordre inverse**
    data_str = msg
    for _ in reversed(route):
        data_str = chiffrement(data_str)

    # Construire le paquet avec DEST
    dest = "C1"
    route_str = ",".join(route)
    packet = f"ROUTE={route_str};DEST={dest};DATA={data_str}"

    # Envoyer au premier routeur
    first_router_port = CONFIG["routers"][route[0]]["port"]
    sock.sendto(packet.encode(), (IP, first_router_port))
