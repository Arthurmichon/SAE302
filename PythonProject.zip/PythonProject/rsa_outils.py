import json
from pathlib import Path
from sympy import isprime
import random

KEYS_DIR = Path("keys")
KEYS_DIR.mkdir(exist_ok=True)

class RSAKey:
    def __init__(self, e: int, d: int, n: int):
        self._e = e
        self._d = d
        self._n = n

    @property
    def e(self):
        return self._e

    @property
    def d(self):
        return self._d

    @property
    def n(self):
        return self._n

    def encrypt(self, message: str) -> list[int]:
        """Chiffrement RSA d'une chaîne de caractères -> liste d'entiers"""
        return [pow(ord(c), self._e, self._n) for c in message]

    def decrypt(self, ciphertext: list[int]) -> str:
        """Déchiffrement RSA d'une liste d'entiers -> chaîne de caractères"""
        return ''.join(chr(pow(c, self._d, self._n)) for c in ciphertext)


# -----------------------
# Fonctions utilitaires
# -----------------------
def generate_prime(bits=16):
    while True:
        n = random.randint(2**(bits-1), 2**bits - 1)
        if isprime(n):
            return n

def generate_keys(bits=16):
    """Génère des clés RSA avec random + isprime"""
    p = generate_prime(bits)
    q = generate_prime(bits)
    while p == q:
        q = generate_prime(bits)
    n = p * q
    phi = (p-1)*(q-1)

    # Choix d'un e premier avec phi
    e = 3
    while phi % e == 0:
        e += 2

    # Calcul de d
    d = pow(e, -1, phi)
    return e, d, n

def save_keys(router_name: str, e: int, d: int, n: int):
    """Sauvegarde les clés dans des fichiers JSON"""
    pub_file = KEYS_DIR / f"{router_name}_public.json"
    priv_file = KEYS_DIR / f"{router_name}_private.json"

    with open(pub_file, "w") as f:
        json.dump({"e": e, "n": n}, f)

    with open(priv_file, "w") as f:
        json.dump({"d": d, "n": n}, f)


def load_public_key(router_name: str) -> RSAKey:
    """Charge la clé publique depuis JSON"""
    pub_file = KEYS_DIR / f"{router_name}_public.json"
    with open(pub_file, "r") as f:
        data = json.load(f)
    return RSAKey(data["e"], 0, data["n"])  # d=0 car non utilisé


def load_private_key(router_name: str) -> RSAKey:
    """Charge la clé privée depuis JSON"""
    priv_file = KEYS_DIR / f"{router_name}_private.json"
    with open(priv_file, "r") as f:
        data = json.load(f)
    return RSAKey(0, data["d"], data["n"])  # e=0 car non utilisé
