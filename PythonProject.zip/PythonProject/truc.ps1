# Script PowerShell : run_scripts.ps1

# Liste des arguments à passer à ton script Python
$routes = @("R1","R2","R3","R4")

foreach ($route in $routes) {
    Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd 'C:\Temp\PythonProject'; python R1.py $route"
}
