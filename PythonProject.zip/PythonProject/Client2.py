import socket
import json

IP = "127.0.0.1"

# Charger la config
with open("router_config.json", "r") as f:
    CONFIG = json.load(f)

PORT_CLIENT = CONFIG["clients"]["C2"]["port"]

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((IP, PORT_CLIENT))

def chiffrement(msg):
    return "".join(chr(ord(c) + 1) for c in msg)

def recevoir():
    while True:
        data, _ = sock.recvfrom(4096)
        msg = data.decode()
        print(f"\n[Client1] : {msg}")  # Affiche le message reçu
        print("Choisis la route (ex: R1,R3,R2) : ", end="", flush=True)  # Réaffiche le prompt sans sauter de ligne

import threading
threading.Thread(target=recevoir, daemon=True).start()

while True:
    route_input = input("Choisis la route (ex: R1,R3,R2) : ")
    route = route_input.split(",")
    msg = input("Message : ")

    # Chiffrer pour chaque routeur, **dans l'ordre inverse**
    data_str = msg
    for _ in reversed(route):
        data_str = chiffrement(data_str)

    # Construire le paquet avec DEST
    dest = "C1"
    route_str = ",".join(route)
    packet = f"ROUTE={route_str};DEST={dest};DATA={data_str}"

    # Envoyer au premier routeur
    first_router_port = CONFIG["routers"][route[0]]["port"]
    sock.sendto(packet.encode(), (IP, first_router_port))
