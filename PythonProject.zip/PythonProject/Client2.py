import socket
import json
import pymysql
from rsa_outils import rsa_encrypt_message
import threading
import sys

IP = "127.0.0.1"

# Charger la config
with open("router_config.json","r") as f:
    CONFIG = json.load(f)

PORT_CLIENT = CONFIG["clients"]["C2"]["port"]

# ---------------------------
# Socket TCP côté client
# ---------------------------
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.bind((IP, PORT_CLIENT))
sock.listen()

# ---------------------------
# Connexion DB
# ---------------------------
db = pymysql.connect(
    host="localhost",
    user="root",
    password="toto",
    database="SAE302",
    charset="utf8mb4"
)
cursor = db.cursor()

# Charge toutes les clés publiques des routeurs
def load_public_keys():
    cursor.execute("SELECT nom, cle_publique FROM routeurs")
    keys = {}
    for nom, cle_json in cursor.fetchall():
        data = json.loads(cle_json)
        keys[nom] = (data["e"], data["n"])
    return keys

public_keys = load_public_keys()

# ---------------------------
# Réception côté client
# ---------------------------
def recevoir():
    while True:
        conn, _ = sock.accept()
        with conn:
            data = conn.recv(65536)  # TCP → gros message possible
            if not data:
                continue
            msg = data.decode()
            # Effacer la ligne actuelle de l'input et afficher le message
            sys.stdout.write('\r' + ' ' * 80 + '\r')  # efface la ligne courante
            print(f"\n>>> Message reçu : {msg}")
            # Réaffiche le prompt
            sys.stdout.write("Route (ex: R1,R3,R2) : ")
            sys.stdout.flush()

threading.Thread(target=recevoir, daemon=True).start()

# ---------------------------
# Envoi
# ---------------------------
while True:
    route_input = input("\nRoute (ex: R1,R3,R2) : ")
    route = route_input.split(",")
    msg = input("Message : ")

    dest = "C1"

    # Onion : chiffrer du dernier router -> premier
    encrypted = msg
    for r in reversed(route):
        e, n = public_keys[r]
        encrypted = rsa_encrypt_message(json.dumps(encrypted), e, n)

    # Préparer paquet
    packet = {
        "route": route,
        "dest": dest,
        "data": encrypted
    }

    first_port = CONFIG["routers"][route[0]]["port"]
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((IP, first_port))
        s.sendall(json.dumps(packet).encode())
