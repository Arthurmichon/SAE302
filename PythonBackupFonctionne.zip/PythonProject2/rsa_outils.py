import pymysql
from pymysql import Error
import random

# ==========================
# Mini-RSA simplifié
# ==========================

class MiniRSAKey:
    def __init__(self, e, d, n):
        self.e = e
        self.d = d
        self.n = n

    # ---------- chiffrement/déchiffrement d'un texte ----------
    def chiffrer(self, m: int) -> int:
        """Chiffre un entier."""
        return pow(m, self.e, self.n)

    def dechiffrer(self, c: int) -> str:
        """Déchiffre un entier en caractère(s)."""
        M = pow(c, self.d, self.n)
        octets = []
        while M > 0:
            octets.append(M & 0xFF)
            M >>= 8
        return ''.join(chr(b) for b in reversed(octets))

    def chiffrer_texte(self, texte: str) -> str:
        """Chiffre un texte en entier(s) pour transmission."""
        return ",".join(str(self.chiffrer(ord(c))) for c in texte)

    def dechiffrer_texte(self, texte_chiffre: str) -> str:
        """Déchiffre un texte transmis sous forme d'entiers séparés par des virgules."""
        if not texte_chiffre.strip():
            return ""
        entiers = [int(x) for x in texte_chiffre.split(",")]
        return "".join(self.dechiffrer(c) for c in entiers)


class GestionCrypto:
    def __init__(self):
        self.privees = {}
        self.publiques = {}

    def generer_cles(self, nom):
        from sympy import randprime
        # Génération de p et q aléatoires distincts
        p = randprime(1000, 5000)
        q = randprime(1000, 5000)
        while p == q:
            q = randprime(1000, 5000)
            
        n = p * q
        phi = (p-1)*(q-1)
        
        # Choisir e premier avec phi
        e = 65537
        # Si e n'est pas copremier avec phi, on change p et q (simplification)
        # Mais 65537 est généralement ok. Vérifions pgcd.
        import math
        while math.gcd(e, phi) != 1:
             p = randprime(1000, 5000)
             q = randprime(1000, 5000)
             phi = (p-1)*(q-1)

        d = pow(e, -1, phi)
        self.privees[nom] = MiniRSAKey(e=None, d=d, n=n)
        self.publiques[nom] = MiniRSAKey(e=e, d=None, n=n)
        return (e, n), (d, n)

    def obtenir_priv(self, nom):
        return self.privees.get(nom)

    def obtenir_pub(self, nom):
        return self.publiques.get(nom)

# ==========================
# Gestion Crypto + MySQL
# ==========================

class GestionCryptoSQL:
    def __init__(self):
        self.crypto = GestionCrypto()

        self.config_bd = {
            "host": "localhost",
            "user": "root",
            "password": "root",
            "database": "SAE302",
            "charset": "utf8mb4"
        }

        self.config_reseau = {
            "routers": {f"R{i}": {"port": 5000 + i} for i in range(1, 21)}
        }

    def creer_base_et_table(self):
        try:
            conn = pymysql.connect(
                host=self.config_bd["host"],
                user=self.config_bd["user"],
                password=self.config_bd["password"],
                charset=self.config_bd["charset"]
            )
            cur = conn.cursor()
            cur.execute(f"CREATE DATABASE IF NOT EXISTS {self.config_bd['database']}")
            conn.commit()
            cur.close()
            conn.close()
        except Error as e:
            print(f"[BD] Erreur creation base : {e}")
            return

        try:
            conn = pymysql.connect(**self.config_bd)
            cur = conn.cursor()
            cur.execute("""
                CREATE TABLE IF NOT EXISTS routeurs (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    nom VARCHAR(20) UNIQUE,
                    ip VARCHAR(15),
                    port INT,
                    cle_publique VARCHAR(255)
                )
            """)
            conn.commit()
            cur.close()
            conn.close()
            print("[BD] Base + Table OK")
        except Error as e:
            print(f"[BD] Erreur creation table : {e}")

    def enregistrer_cle_publique(self, nom_routeur, n_pub):
        try:
            conn = pymysql.connect(**self.config_bd)
            cur = conn.cursor()
            sql = (
                "INSERT INTO routeurs (nom, ip, port, cle_publique) "
                "VALUES (%s,%s,%s,%s) "
                "ON DUPLICATE KEY UPDATE ip=VALUES(ip), port=VALUES(port), cle_publique=VALUES(cle_publique)"
            )
            ip = "127.0.0.1"
            port = self.config_reseau["routers"][nom_routeur]["port"]

            cur.execute(sql, (nom_routeur, ip, port, str(n_pub)))
            conn.commit()
            cur.close()
            conn.close()
        except Exception as e:
            print(f"[BD] Erreur enregistrer_cle_publique : {e}")

    def charger_cles_publiques(self):
        res = {}
        try:
            conn = pymysql.connect(**self.config_bd)
            cur = conn.cursor()
            cur.execute("SELECT nom, cle_publique FROM routeurs")
            for nom, n in cur.fetchall():
                res[nom] = MiniRSAKey(e=65537, d=None, n=int(n))
            cur.close()
            conn.close()
        except Exception as e:
            print(f"[BD] Erreur chargement clés publiques : {e}")
        return res

    def generer_toutes_les_cles(self):
        self.creer_base_et_table()
        for nom in self.config_reseau["routers"]:
            print(f"[*] Génération clés {nom}")
            (e, n), (d, _) = self.crypto.generer_cles(nom)
            self.enregistrer_cle_publique(nom, n)
        print("[OK] Toutes les clés générées & stockées en BD")

    def initialiser_routeur(self, nom):
        self.creer_base_et_table()
        print(f"[*] Génération clé pour {nom}")
        (e, n), (d, _) = self.crypto.generer_cles(nom)
        self.enregistrer_cle_publique(nom, n)
        print(f"[OK] Clé {nom} générée & stockée")

    def obtenir_cle_privee(self, nom):
        return self.crypto.obtenir_priv(nom)

    # ==========================
    # Gestion Clients (Port)
    # ==========================

    def enregistrer_client(self, nom_client, port):
        try:
            conn = pymysql.connect(**self.config_bd)
            cur = conn.cursor()
            # On crée la table au cas où
            cur.execute("""
                CREATE TABLE IF NOT EXISTS clients (
                    nom VARCHAR(20) PRIMARY KEY,
                    port INT
                )
            """)
            sql = (
                "INSERT INTO clients (nom, port) VALUES (%s, %s) "
                "ON DUPLICATE KEY UPDATE port=VALUES(port)"
            )
            cur.execute(sql, (nom_client, port))
            conn.commit()
            cur.close()
            conn.close()
            print(f"[BD] Client {nom_client} enregistré sur le port {port}")
        except Exception as e:
            print(f"[BD] Erreur enregistrement client : {e}")

    def obtenir_port_client(self, nom_client):
        port = None
        try:
            conn = pymysql.connect(**self.config_bd)
            cur = conn.cursor()
            cur.execute("SELECT port FROM clients WHERE nom=%s", (nom_client,))
            res = cur.fetchone()
            if res:
                port = res[0]
            cur.close()
            conn.close()
        except Exception as e:
            print(f"[BD] Erreur lecture port client : {e}")
        return port

