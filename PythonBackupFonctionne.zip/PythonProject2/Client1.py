import socket
import threading
from rsa_outils import GestionCryptoSQL

IP = "127.0.0.1"


# ============================================
# Initialisation
# ============================================

g = GestionCryptoSQL()
# g.generer_toutes_les_cles() # STOP : Client ne doit pas écraser les clés !


nom_client = "C1"
nom_dest = "C2"  # toujours l'autre client

# Port manuel
port = int(input(f"[{nom_client}] Entrez votre port : "))

# Clé publique du premier routeur de la route
cles_publiques = g.charger_cles_publiques()

# ============================================
# Enregistrement en Base de Données
# ============================================

def enregistrer_client_bd():
    try:
        g.enregistrer_client(nom_client, port)
    except Exception as e:
        print(f"[{nom_client}] Erreur enregistrement BD : {e}")

enregistrer_client_bd()

# ============================================
# Réception des messages
# ============================================

def recevoir():
    serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    serveur.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    serveur.bind((IP, port))
    serveur.listen()
    print(f"[{nom_client}] Serveur démarré sur port {port}...\n")
    while True:
        conn, _ = serveur.accept()
        threading.Thread(target=gerer_connexion, args=(conn,), daemon=True).start()

def gerer_connexion(conn):
    with conn:
        chunks = []
        while True:
            chunk = conn.recv(65536)
            if not chunk:
                break
            chunks.append(chunk)

        if not chunks:
            return
        message = b"".join(chunks).decode()
        print(f"\n[{nom_client}] Reçu : {message}\nRoute (ex: R1,R3,R2): ", end="")

threading.Thread(target=recevoir, daemon=True).start()

# ============================================
# Envoi des messages
# ============================================

while True:
    try:
        route_str = input("Route (ex: R1,R3,R2) [ou 'random', 'quit'] : ").strip()
        if not route_str:
            continue
        
        # Commande QUIT : Eteindre tout le monde
        if route_str.lower() == "quit":
            print("Arrêt général du système...")
            for r_nom, r_conf in g.config_reseau["routers"].items():
                try:
                    p = r_conf["port"]
                    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                        s.connect((IP, p))
                        s.sendall("CMD|SHUTDOWN".encode())
                    print(f"Signal d'arrêt envoyé à {r_nom}")
                except:
                    pass
            import sys
            sys.exit(0)

        # Commande RANDOM : Route aléatoire
        if route_str.lower() == "random":
            import random
            tous_routeurs = list(g.config_reseau["routers"].keys())
            # On prend entre 2 et 5 routeurs (ou max dispo)
            nb_sauts = random.randint(2, min(5, len(tous_routeurs)))
            route = random.sample(tous_routeurs, nb_sauts)
            print(f"-> Route aléatoire générée : {','.join(route)}")
        else:
            route = route_str.split(",")

        message = input("Message : ")

        # On chiffre le message en cascade selon la route
        texte_courant = message
        for r in reversed(route):
            if r not in cles_publiques:
                print(f"Erreur: Routeur '{r}' inconnu ou sans clé publique.")
                break
            cle_pub = cles_publiques[r]
            texte_courant = cle_pub.chiffrer_texte(texte_courant)
        else:
            # Cette partie s'exécute si pas de break (donc routeurs valides)
            
            # Construire le paquet final
            paquet = ";".join(route) + f"|{nom_dest}|{texte_courant}"

            # Envoyer au premier routeur de la route
            premier_r = route[0]
            if premier_r in g.config_reseau["routers"]:
                port_r = g.config_reseau["routers"][premier_r]["port"]
                try:
                    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                        s.connect((IP, port_r))
                        s.sendall(paquet.encode())
                    print(f"[{nom_client}] Message envoyé via {route_str}")
                except Exception as e:
                    print(f"Erreur envoi au routeur {premier_r}: {e}")
            else:
                 print(f"Premier routeur {premier_r} non trouvé dans la config.")

    except KeyboardInterrupt:
        break
    except Exception as e:
        print(f"Erreur : {e}")
