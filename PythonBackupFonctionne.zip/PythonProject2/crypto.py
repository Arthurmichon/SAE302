import random
from math import gcd

# ============================================
# MINI RSA (asymétrique, simple, fiable)
# ============================================

class MiniRSAKey:
    def __init__(self, e=None, d=None, n=None):
        self.e = e
        self.d = d
        self.n = n

    def chiffrer(self, texte: str) -> str:
        """Chiffre chaque caractère séparément (aucune erreur possible)."""
        e, n = self.e, self.n
        return ";".join(str(pow(ord(c), e, n)) for c in texte)

    def dechiffrer(self, texte_chiffre: str) -> str:
        d, n = self.d, self.n
        if texte_chiffre.strip() == "":
            return ""
        valeurs = [int(x) for x in texte_chiffre.split(";")]
        return "".join(chr(pow(v, d, n)) for v in valeurs)


class GestionCrypto:
    """Ne gère que la génération interne des clés (sans base)."""

    def __init__(self):
        self.cles_pub = {}
        self.cles_priv = {}

    def _premier(self, n):
        if n < 2: return False
        for i in range(2, int(n**0.5) + 1):
            if n % i == 0: return False
        return True

    def _gen_prime(self):
        p = random.randint(200, 400)
        while not self._premier(p):
            p += 1
        return p

    def generer_cles(self, nom):
        p = self._gen_prime()
        q = self._gen_prime()
        while q == p:
            q = self._gen_prime()

        n = p * q
        phi = (p - 1) * (q - 1)

        e = 5
        while gcd(e, phi) != 1:
            e += 2

        d = pow(e, -1, phi)

        self.cles_pub[nom] = (e, n)
        self.cles_priv[nom] = (d, n)

        return (e, n), (d, n)

    def obtenir_pub(self, nom):
        e, n = self.cles_pub[nom]
        return MiniRSAKey(e=e, n=n)

    def obtenir_priv(self, nom):
        d, n = self.cles_priv[nom]
        return MiniRSAKey(d=d, n=n)
