import socket
import sys
import threading
from rsa_outils import GestionCryptoSQL

IP = "127.0.0.1"

# ============================================
# Initialisation Crypto + SQL
# ============================================

g = GestionCryptoSQL()
nom_routeur = sys.argv[1] if len(sys.argv) > 1 else "R1"

# On initialise uniquement la clé de CE routeur
# (au lieu de tout régénérer et écraser les autres)
g.initialiser_routeur(nom_routeur)

port = g.config_reseau["routers"][nom_routeur]["port"]

cle_privee = g.obtenir_cle_privee(nom_routeur)

print(f"[{nom_routeur}] Démarré sur port {port}, n={cle_privee.n}")

# ============================================
# Serveur TCP
# ============================================

serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
serveur.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
serveur.bind((IP, port))
serveur.listen()
print(f"[{nom_routeur}] En écoute...\n")

# ============================================
# Format paquet : route|dest|C
# ============================================

def parser_paquet(txt):
    parts = txt.split("|", 2)
    route = parts[0].split(";") if parts[0] else []
    dest = parts[1]
    C = parts[2]
    return route, dest, C

def construire_paquet(route, dest, C):
    return ";".join(route) + "|" + dest + "|" + C

# ============================================
# Dictionnaire pour stocker les clients connectés
# clé = nom_client, valeur = port_client
# ============================================

clients_connectes = {}

# ============================================
# Gestion connexion
# ============================================

def gerer(conn):
    with conn:
        # Lecture en boucle pour récupérer tout le message (peut dépasser 65Ko avec l'oignon)
        chunks = []
        while True:
            chunk = conn.recv(65536)
            if not chunk:
                break
            chunks.append(chunk)
        
        if not chunks:
            return
            
        data = b"".join(chunks)
        texte = data.decode()

        # Cas spécial : enregistrement client (prefixe "CLIENT|nom|port")
        if texte.startswith("CLIENT|"):
            _, nom_client, port_client = texte.split("|")
            clients_connectes[nom_client] = int(port_client)
            print(f"[{nom_routeur}] Client enregistré : {nom_client} sur port {port_client}")
            return

        # Cas spécial : demande d'arrêt global
        if texte == "CMD|SHUTDOWN":
            print(f"[{nom_routeur}] ARRÊT D'URGENCE DEMANDÉ.")
            import os
            os._exit(0)

        # Cas normal : message à router
        route, dest, C = parser_paquet(texte)
        print(f"[{nom_routeur}] Reçu route={route}, C={C}")

        # Si plusieurs entiers séparés par ';', convertir en liste
        try:
            C_ints = [int(x) for x in C.split(",")]
        except ValueError:
            print(f"[{nom_routeur}] Erreur conversion C en int : {C}")
            return

        # Déchiffrement
        # C_ints est la liste des blocs chiffrés pour MOI
        clair = "".join(cle_privee.dechiffrer(c) for c in C_ints)
        print(f"[{nom_routeur}] → Déchiffré : '{clair}'")

        # Dernier routeur : envoyer au client
        if len(route) == 1:
            # Recherche du port client en base de données (plus robuste)
            port_dest = g.obtenir_port_client(dest)
            
            # Fallback : recherche locale si non trouvé en BD (pour compatibilité)
            if port_dest is None:
                port_dest = clients_connectes.get(dest)

            if port_dest is None:
                print(f"[{nom_routeur}] ERREUR : port du client {dest} inconnu (ni en mémoire, ni en BD)")
                return
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.connect((IP, port_dest))
                    s.sendall(clair.encode())
                print(f"[{nom_routeur}] Message final envoyé au client {dest} sur le port {port_dest}")
            except Exception as e:
                print(f"[{nom_routeur}] ERREUR envoi au client {dest} : {e}")
            return

        # Routeur suivant
        next_r = route[1]
        next_route = route[1:]

        # Le payload déchiffré (clair) est déjà chiffré pour le suivant dans l'oignon
        # On ne re-chiffre PAS. On transmet tel quel.
        C_suivant = clair

        paquet = construire_paquet(next_route, dest, C_suivant)

        port_suiv = g.config_reseau["routers"][next_r]["port"]
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((IP, port_suiv))
                s.sendall(paquet.encode())
            print(f"[{nom_routeur}] → Transmis à {next_r}")
        except Exception as e:
            print(f"[{nom_routeur}] ERREUR envoi à {next_r} : {e}")

# ============================================
# Boucle principale
# ============================================

while True:
    conn, _ = serveur.accept()
    threading.Thread(target=gerer, args=(conn,), daemon=True).start()
