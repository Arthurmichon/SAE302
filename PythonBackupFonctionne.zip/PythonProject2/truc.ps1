# ============================================
# Script PowerShell - Lance tous les fichiers
# ============================================
# Ce script lance :
# 1. Les 4 routeurs (R1, R2, R3, R4) dans des terminaux separes
# 2. Les 2 clients (Client1, Client2) dans des terminaux separes
# ============================================
# ============================================
# INSTALLATION AUTOMATIQUE DES LIBRAIRIES PYTHON
# ============================================

Write-Host "Verification / installation des librairies Python (sympy, pymysql)..."

# Utilise le python par defaut
$python = "python"

# Fonction utilitaire pour installer un package si besoin
function Ensure-Package {
    param(
        [string]$PackageName
    )
    Write-Host "  -> $PackageName" -NoNewline

    $checkCmd = "$python -m pip show $PackageName"
    $installed = Invoke-Expression $checkCmd 2>$null

    if (-not $installed) {
        Write-Host " (installation en cours...)"
        $installCmd = "$python -m pip install $PackageName"
        Invoke-Expression $installCmd
    } else {
        Write-Host " (deja installe)"
    }
}

Ensure-Package "sympy"
Ensure-Package "pymysql"
Ensure-Package "requests"

Write-Host "Librairies verifiees."
# Repertoire du projet (automatique)
$PROJECT_DIR = $PSScriptRoot
Set-Location $PROJECT_DIR

Write-Host "========================================"
Write-Host "Demarrage du systeme de routage RSA"
Write-Host "========================================"
Write-Host ""
Write-Host "Les onglets vont s'ouvrir dans Windows Terminal..."

# ============================================
# DEMARRAGE DES ROUTEURS
# ============================================

# ============================================
# DEMARRAGE DES ROUTEURS (1 à 20)
# ============================================

# Note: "-w 0" cible la fenetre active de Windows Terminal.
# Nous n'utilisons PAS "-NoExit" ici : quand le script Python fera os._exit(0), l'onglet se fermera.

Write-Host "Lancement des 20 routeurs..."
for ($i=1; $i -le 20; $i++) {
    $rName = "R$i"
    Write-Host "  -> $rName"
    Start-Process wt -ArgumentList "-w", "0", "new-tab", "--title", "`"$rName`"", "-d", "`"$PROJECT_DIR`"", "powershell", "-Command", "python R1.py $rName"
    Start-Sleep -Milliseconds 300
}

# ============================================
# DEMARRAGE DES CLIENTS (Nouvelle fenêtre)
# ============================================

Write-Host "Lancement des Clients (dans une nouvelle fenêtre)..."

# On lance une NOUVELLE instance de wt (sans -w 0) pour séparer les clients des routeurs
# On enchaine deux onglets dans cette nouvelle fenêtre avec ";"
$cmdClients = "new-tab --title `"Client 1`" -d `"$PROJECT_DIR`" powershell -NoExit -Command python Client1.py ; new-tab --title `"Client 2`" -d `"$PROJECT_DIR`" powershell -NoExit -Command python Client2.py"

Start-Process wt -ArgumentList "-w", "new", $cmdClients
Start-Sleep -Seconds 2

# ============================================
# MESSAGE FINAL
# ============================================

Write-Host ""
Write-Host "========================================"
Write-Host "SUCCES - Tous les processus ont ete lances !"
Write-Host "========================================"
Write-Host ""
Write-Host "Les terminaux sont maintenant ouverts :"
Write-Host "  Terminal 1 : Routeur R1 (port 5001)"
Write-Host "  Terminal 2 : Routeur R2 (port 5002)"
Write-Host "  Terminal 3 : Routeur R3 (port 5003)"
Write-Host "  Terminal 4 : Routeur R4 (port 5004)"
Write-Host "  Terminal 5 : Client 1 (port 4001)"
Write-Host "  Terminal 6 : Client 2 (port 4002)"
Write-Host ""
Write-Host "Pour envoyer un message :"
Write-Host "  1. Allez dans le terminal Client 1 ou Client 2"
Write-Host "  2. Entrez une route (ex: R1,R2,R3)"
Write-Host "  3. Entrez un message"
Write-Host ""
Write-Host "Le message traversera tous les routeurs cryptes !"
Write-Host ""
