=============================================================================
GUIDE D'INSTALLATION ET D'UTILISATION - PROJET ONION ROUTING (MULTI-PC)
=============================================================================
(en cas de problèmes regarder tout en bas de ce fichier)

Pré-requis : 	Python 3.10+ installé sur toutes les machines.
		Installer MariaDB (Linux) ou MySQL (Windows)
		Copiez les fichiers du projet sur chaque PC.

Avant de démarrer le Projet :

Vérifier que tout les PC soient sur le même réseaux. Pour vérifier, il faut que toutes les adresses IP est au début (par exemple): 10.213.2.x
Faire sur Linux : ip a
Faire sur Windows : ipconfig
et regarder sur la carte réseau utilisé.


INSTALLATION de la BDD :
--------------------------------
1. Installer MariaDB pour linux ou MySQL pour Windows.
MariaDB :
	1. Ecrire dans un termnial : sudo mariadb		(Si mariadb n'est pas démarré faire : systemctl sart mariadb)
	2. Copier coller dans le terminal les commandes de l'étapes 2
MySQL :
	1. Ecrire dans un terminal : 	net start MySQL80  	<- Mettre le nom qui correspond de mysql
	2. Ensuite : 			mysql -u root -p	<- Inscrivez votre mdp pour root (si cette commande ne marche pas, c'est possiblement car il faut mettre le chemin exacte donc aller dans : "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe", clique-droit -> Ouvrir dans le Terminal -> mysql -u root -p)

2. Quand vous êtes connecter à MySQL ou MariaDB :
   - Copier coller les commandes (elles permettent de créer un user pour que les scripts puissent si connecter, puis créer les tables de la BDD) :

      CREATE user 'user_onion'@'%' IDENTIFIED BY 'onion_pass';      
      GRANT ALL PRIVILEGES ON *.* TO 'user_onion'@'%' IDENTIFIED BY 'onion_pass' WITH GRANT OPTION;
      FLUSH PRIVILEGES;


-- Table Routeurs
CREATE TABLE IF NOT EXISTS routeurs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(20) UNIQUE,
    ip VARCHAR(15),
    port INT,
    cle_publique TEXT
) CHARACTER SET utf8 COLLATE utf8_general_ci;

-- Table Clients
CREATE TABLE IF NOT EXISTS clients (
    nom VARCHAR(20) PRIMARY KEY,
    port INT,
    ip VARCHAR(50) DEFAULT '127.0.0.1'
) CHARACTER SET utf8 COLLATE utf8_general_ci;

-- Table Logs
CREATE TABLE IF NOT EXISTS sys_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    horodatage TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    source VARCHAR(50),
    message TEXT
) CHARACTER SET utf8 COLLATE utf8_general_ci;


=============================================================================
ETAPE 1 : CONFIGURATION DU MASTER
=============================================================================

Sur le PC qui va gérer les routeurs qui servent de relais (interface graphique).

Sur Windows (vous pouvez lancer un terminal en mode administrateur avec clic droit sur cmd et "Executer en tant qu'administrateur") : 
	1. Lancez un environnement virtuel (pas obligatoire mais conseillé):
		cd <chemin/du/projet>
		Python -m venv venv (ou : Python3 -m venv venv)
		Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass	<- Si les commandes 	powershell ne sont pas autorisé
		venv\Scripts\activate
	2. Lancez avec la commande : 		.\install_master.ps1
	3. Lancez `Master.py` sur le PC : 	python Master.py
 	4. En haut de la fenêtre :
   		- IP Base de Données (SQL) : Si la BDD est sur ce pc vous pouvez mettre 127.0.0.1 sinon mettre l'adresse IP du PC 1 donc de la BDD (ex: 192.168.1.10).
  		- Port : 3306 (Défaut).
	5. Cliquez sur "Connecter BDD".
	6. Lancez les routeurs (Bouton "Lancer TOUT" ou bouton ON/OFF individuel), ou bien avec la commande : 
		-> python R1.py Rx <ipdelaBDD>:<portdelaBDD> <portdurouteur> (exemple : python R1.py R1 127.0.0.1:3306 4001)
   		-> Les routeurs vont s'ouvrir, détecter leur IP LAN et s'enregistrer dans la base sur le PC 1.

Sur Linux (vous pouvez lancez un terminal en faisaint sudo su ou sudo -s (puis votre mdp) pour mettre en mode administrateur:
	1. Lancez un environnement virtuel (pas obligatoire mais conseillé): 
		cd <chemin/du/projet>
		(Si pas installer faire : sudo apt update	et 	sudo apt install python3 python3-venv python3-pip) aussi, si vous avez cassé un environnement virtuel faire : rm -rf venv
		Python3 -m venv venv
		source venv/bin/activate
	2. Lancez les commandes :
		- pip install pymysql
		- pip install sympy
		- pip install PyQt5
	3. Lancez `Master.py` sur le PC : 	python Master.py		
 	4. En haut de la fenêtre :
   		- IP Base de Données (SQL) : Si la BDD est sur ce pc vous pouvez mettre 127.0.0.1 sinon mettre l'adresse IP du PC 1 donc de la BDD (ex: 192.168.1.10).
  		- Port : 3306 (Défaut).
	5. Cliquez sur "Connecter BDD".
	6. Lancez les routeurs (Le bouton "Lancer TOUT" ne fonctionnera pas car c'est du powershell qui n'est pas présent sur Linux, ainsi cliquer sur les boutons ON/OFF individuel).
   		-> Les routeurs vont s'ouvrir, détecter leur IP LAN et s'enregistrer dans la base sur le PC 1.

=============================================================================
ETAPE 2 : CONFIGURATION DES CLIENTS
=============================================================================
Pour communiquer, lancez un client sur un PC et un autre sur un autre PC.
Sur Windows :
	1. Lancez une interface virtuel venv (pas obligatoire)
	2. Lancez .\install_client.ps1
	3. Lancez `ClientGUI.py`.
	4. Configuration Réseau :
   		- Nom Unique : Choisissez un pseudo (ex: "Alice" ou encore "Client1" sur un premier PC, "Bob" ou "Client2" sur un deuxième PC).
   		- Mon IP LAN : Détectée automatiquement (Vérifiez qu'elle est correcte).
   		- IP BDD (Master) : Entrez l'IP du PC 1 donc du pc ou il y a la BDD ("ipconfig" pour voir l'add IP sur Windows et "ip a" sur Linux.
	5. Cliquez sur "Démarrer Client".

Sur Linux :
	1. Lancez une interface virtuel venv (pas obligatoire)
	2. Installer grâce à ces commandes :
		- pip install pymysql
		- pip install sympy
		- pip install PyQt5
	3. Lancez `ClientGUI.py`.
	4. Configuration Réseau :
   		- Nom Unique : Choisissez un pseudo (ex: "Alice" ou encore "Client1" sur un premier PC, "Bob" ou "Client2" sur un deuxième PC).
   		- Mon IP LAN : Détectée automatiquement (Vérifiez qu'elle est correcte).
   		- IP BDD (Master) : Entrez l'IP du PC 1 donc du pc ou il y a la BDD ("ipconfig" pour voir l'add IP sur Windows et "ip a" sur Linux. Si le Master est bien sur le pc de la BDD, l'add IP est indiquer tout en en rouge de l'interface graphique).
	5. Cliquez sur "Démarrer Client".

=============================================================================
ETAPE 3 : UTILISATION
=============================================================================

Lancez les routeurs souhaitez depuis le master ou à l'aide de la commande : python R1.py Rx -m 192.168.0.1:3306 -p 5021   <- Rx = Numéro du routeurs souhaité, après le -m vous écrivez l'adresse du pc ou est la BDD ainsiq que son port et -p est le port qu'utilisera le routeur (dans l'exemple c'est 5021)

Pour envoyer un message d'Alice (PC 2) à Bob (PC 3) :

1. Sur l'interface d'Alice :
   - Route : "random" (ou une liste "R1,R5"). Si random est indiqué vous pouvez indiquer le nombre de routeurs que vous voulez (il ne prendra que les routeurs allumés)
   - Message : "Bonjour Bob !"
   - Destinataire : "Bob" (Le nom exact utilisé par l'autre client).
2. Cliquez sur Envoyer.
3. Observez :
   - Les messages défilent dans les fenêtres noires des routeurs sur le PC 2.
   - Bob reçoit le message sur le PC 3(vous pouvez aussi regarder les logs dans les clients pour voie le chemin utilisé).

=============================================================================
DÉPANNAGE COURANT
=============================================================================
1. "Impossible de se connecter à la BDD" :
   - Vérifiez que le PC 1 a bien lancé MySQL.
   - Vérifiez que les pare-feu des PC autorisent le port 3306. Pour ne plus avoir ce problème, désactivé le pare-feu -> Pare-feu Windows defender -> Modifier les paramètres de notifications -> >Tout désactiver (n'oubliez pas de les réactiver après)
   - Vérifiez que vous avez saisi la bonne IP du PC 1.

2. "Connexion au routeur refusée" :
   - Vérifiez que les routeurs sont bien lancés (Status VERT sur Master).
   - Vérifiez que l'IP LAN détectée par les routeurs est accessible depuis le PC Client.
   - Vérifiez le pare-feu du PC client (Port 5000+).

3. "Client introuvable" :
   - Vérifiez que le destinataire a bien cliqué sur "Démarrer Client".
   - Vérifiez que vous avez tapé son nom EXACT (Attention aux majuscules !).
