=============================================================================
GUIDE D'INSTALLATION ET D'UTILISATION - PROJET ONION ROUTING (MULTI-PC)
=============================================================================

Pré-requis : Python 3.10+ installé sur toutes les machines.
Librairies requises : PyQt5, pymysql, sympy

INSTALLATION RAPIDE SUR LES PC :
--------------------------------
1. Copiez les fichiers du projet sur chaque PC.
2. PC 1 (Celui qui aura la BASE DE DONNÉES) :
   - Lancez `install_db.ps1` (Clic droit -> Exécuter avec PowerShell).
   - Cela configure la base et les tables.

3. PC 2 et PC 3 (Routeurs et Clients) :
   - Lancez `install_master.ps1` ou `install_client.ps1` pour installer les librairies Python si nécessaire.

=============================================================================
ETAPE 1 : CONFIGURATION DU RÉSEAU (PC 2 - MAÎTRE DES ROUTEURS)
=============================================================================
Le PC 2 va gérer les routeurs qui servent de relais.

1. Lancez `Master.py` sur le PC 2.
2. En haut de la fenêtre :
   - IP Base de Données (SQL) : Entrez l'IP du PC 1 (ex: 192.168.1.10).
   - Port : 3306 (Défaut).
3. Cliquez sur "Connecter BDD".
4. Lancez les routeurs (Bouton "Lancer TOUT" ou bouton ON/OFF individuel).
   -> Les routeurs vont s'ouvrir, détecter leur IP LAN et s'enregistrer dans la base sur le PC 1.

=============================================================================
ETAPE 2 : CONFIGURATION DES CLIENTS (PC 2 et PC 3)
=============================================================================
Pour communiquer, lancez un client sur le PC 2 et un autre sur le PC 3.

1. Lancez `ClientGUI.py`.
2. Configuration Réseau :
   - Nom Unique : Choisissez un pseudo (ex: "Alice" sur PC 2, "Bob" sur PC 3).
   - Mon IP LAN : Détectée automatiquement (Vérifiez qu'elle est correcte).
   - IP BDD (Master) : Entrez l'IP du PC 1 (La même que utilisée par le Master !).
3. Cliquez sur "Démarrer Client".

=============================================================================
ETAPE 3 : UTILISATION
=============================================================================

Pour envoyer un message d'Alice (PC 2) à Bob (PC 3) :

1. Sur l'interface d'Alice :
   - Route : "random" (ou une liste "R1,R5").
   - Destinataire : "Bob" (Le nom exact utilisé par l'autre client).
   - Message : "Bonjour Bob !"
2. Cliquez sur Envoyer.
3. Observez :
   - Les messages défilent dans les fenêtres noires des routeurs sur le PC 2.
   - Bob reçoit le message sur le PC 3.

=============================================================================
DÉPANNAGE COURANT
=============================================================================
1. "Impossible de se connecter à la BDD" :
   - Vérifiez que le PC 1 a bien lancé MySQL.
   - Vérifiez que le pare-feu du PC 1 autorise le port 3306. 
   - Vérifiez que vous avez saisi la bonne IP du PC 1.

2. "Connexion au routeur refusée" :
   - Vérifiez que les routeurs sont bien lancés (Status VERT sur Master).
   - Vérifiez que l'IP LAN détectée par les routeurs est accessible depuis le PC Client.
   - Vérifiez le pare-feu du PC 2 (Port 5000+).

3. "Client introuvable" :
   - Vérifiez que le destinataire a bien cliqué sur "Démarrer Client".
   - Vérifiez que vous avez tapé son nom EXACT (Attention aux majuscules !).
