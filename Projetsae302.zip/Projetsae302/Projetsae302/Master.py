import sys
import subprocess
import socket
import threading
import os
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
    QTabWidget, QTableWidget, QTableWidgetItem, QPushButton, 
    QLabel, QFrame, QScrollArea, QGridLayout, QMessageBox, QHeaderView,
    QGroupBox, QLineEdit
)
from PyQt5.QtCore import QTimer, Qt
from PyQt5.QtGui import QColor, QFont
from rsa_outils import GestionCryptoSQL

class MasterGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("MASTER Controller - Onion Routing (Qt)")
        self.resize(900, 800)

        self.g = GestionCryptoSQL()
        self.router_widgets = {}
        
        # Widget Central
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)

        # -- Affichage IP Locale --
        local_ip = "127.0.0.1"
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
        except:
            pass
            
        lbl_info_ip = QLabel(f"Mon IP Locale (PC Maître) : {local_ip}  <-- Mettre cette IP dans le script Client !")
        lbl_info_ip.setAlignment(Qt.AlignCenter)
        lbl_info_ip.setStyleSheet("font-size: 14px; font-weight: bold; color: #E91E63; margin-bottom: 5px;")
        layout.addWidget(lbl_info_ip)

        # Zone Configuration (IP/Port)
        group_config = QGroupBox("Configuration Générale")
        layout_config = QHBoxLayout()
        
        self.input_ip = QLineEdit("127.0.0.1")
        self.input_port = QLineEdit("3306") # Port DB ou autre par défaut
        
        layout_config.addWidget(QLabel("IP Base de Données (SQL):"))
        layout_config.addWidget(self.input_ip)
        layout_config.addWidget(QLabel("Port Base de Données:"))
        layout_config.addWidget(self.input_port)
        
        # New Connect Button
        self.btn_connect = QPushButton("Connecter BDD")
        self.btn_connect.setStyleSheet("background-color: #2196F3; color: white; font-weight: bold;")
        self.btn_connect.clicked.connect(self.connect_db)
        layout_config.addWidget(self.btn_connect)
        
        group_config.setLayout(layout_config)
        layout.addWidget(group_config)

        # Onglets
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs)

        # Tab 1: Logs
        self.tab_logs = QWidget()
        self.setup_tab_logs()
        self.tabs.addTab(self.tab_logs, "Logs Système")

        # Tab 2: Clés
        self.tab_keys = QWidget()
        self.setup_tab_keys()
        self.tabs.addTab(self.tab_keys, "Clés Publiques")

        # Tab 3: Contrôle
        self.tab_control = QWidget()
        self.setup_tab_control()
        self.tabs.addTab(self.tab_control, "Contrôle Routeurs")

        # Timer de rafraichissement (Logs + Clés)
        self.timer_update = QTimer()
        self.timer_update.timeout.connect(self.periodic_update)
        self.timer_update.start(1000) # Always run to update UI

        # Timer pour scanner les statuts (rapide)
        self.timer_status = QTimer()
        self.timer_status.timeout.connect(self.check_routers_status)
        self.timer_status.start(1000) # Always run scan
        
        self.router_states = {} # Initial state container

        # NOTE: self.router_widgets is already populated by setup_tab_control called above.
        # Do NOT reset it here.
        
        self.db_connected = False # Flag

    def setup_tab_logs(self):
        layout = QVBoxLayout(self.tab_logs)
        
        # Tableau
        self.table_logs = QTableWidget()
        self.table_logs.setColumnCount(3)
        self.table_logs.setHorizontalHeaderLabels(["Heure", "Source", "Message"])
        self.table_logs.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents) # Heure
        self.table_logs.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents) # Source
        self.table_logs.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch) # Message
        
        layout.addWidget(self.table_logs)

        # Bouton Vider
        btn_vider = QPushButton("Vider Logs")
        btn_vider.clicked.connect(self.vider_logs)
        layout.addWidget(btn_vider, alignment=Qt.AlignRight)

    def setup_tab_keys(self):
        layout = QVBoxLayout(self.tab_keys)
        
        self.table_keys = QTableWidget()
        self.table_keys.setColumnCount(3)
        self.table_keys.setHorizontalHeaderLabels(["Routeur", "Port", "Clé Publique (n)"])
        self.table_keys.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        
        layout.addWidget(self.table_keys)

    def setup_tab_control(self):
        layout = QVBoxLayout(self.tab_control)

        # 1. Zone Gestion (Ajout/Suppression)
        group_manage = QGroupBox("Gestion Routeurs")
        layout_manage = QHBoxLayout()
        
        self.input_router_name = QLineEdit()
        self.input_router_name.setPlaceholderText("Nom (ex: R21)")
        self.input_router_port = QLineEdit()
        self.input_router_port.setPlaceholderText("Port (ex: 5021)")
        
        btn_add = QPushButton("Ajouter")
        btn_add.clicked.connect(self.add_router)
        btn_add.setStyleSheet("background-color: #2196F3; color: white;")

        btn_del = QPushButton("Supprimer (Nom)")
        btn_del.clicked.connect(self.delete_router)
        btn_del.setStyleSheet("background-color: #F44336; color: white;")
        
        layout_manage.addWidget(QLabel("Nom:"))
        layout_manage.addWidget(self.input_router_name)
        layout_manage.addWidget(QLabel("Port:"))
        layout_manage.addWidget(self.input_router_port)
        layout_manage.addWidget(btn_add)
        layout_manage.addWidget(btn_del)
        
        group_manage.setLayout(layout_manage)
        layout.addWidget(group_manage)

        # 2. Actions Globales
        group_global = QGroupBox("Actions Globales")
        layout_global = QHBoxLayout()
        btn_run_all = QPushButton("Lancer TOUT")
        btn_run_all.setStyleSheet("background-color: #4CAF50; color: white; font-weight: bold; padding: 10px;")
        btn_run_all.clicked.connect(self.run_global_script)
        layout_global.addWidget(btn_run_all)
        group_global.setLayout(layout_global)
        layout.addWidget(group_global)

        # 3. Zone défilante pour les routeurs
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        layout.addWidget(scroll_area)

        self.content_widget = QWidget()
        scroll_area.setWidget(self.content_widget)
        
        self.grid_layout = QGridLayout(self.content_widget)
        
        # Initial draw
        self.refresh_router_grid()

    def refresh_router_grid(self):
        # Save config for external script (truc.ps1) - TXT format (No JSON)
        self.save_config_txt()

        # Clear existing layout
        for i in reversed(range(self.grid_layout.count())): 
            self.grid_layout.itemAt(i).widget().setParent(None)
        
        self.router_widgets = {}

        # Sort keys naturally
        keys = sorted(self.g.config_reseau["routers"].keys(), key=lambda x: int(x[1:]) if x[1:].isdigit() else x)
        
        for i, nom in enumerate(keys):
            port = self.g.config_reseau["routers"][nom]["port"]
            
            # Frame par routeur
            frame = QGroupBox()
            frame.setStyleSheet("QGroupBox { border: 1px solid gray; border-radius: 5px; margin-top: 5px; }")
            vbox = QVBoxLayout()
            
            # Titre + Port
            lbl_nom = QLabel(f"{nom}\n({port})")
            lbl_nom.setAlignment(Qt.AlignCenter)
            lbl_nom.setFont(QFont("Arial", 10, QFont.Bold))
            vbox.addWidget(lbl_nom)

            # Status
            lbl_status = QLabel("OFF")
            lbl_status.setAlignment(Qt.AlignCenter)
            lbl_status.setStyleSheet("background-color: red; color: white; border-radius: 3px; padding: 2px;")
            lbl_status.setFixedSize(60, 25)
            hbox_status = QHBoxLayout()
            hbox_status.addStretch()
            hbox_status.addWidget(lbl_status)
            hbox_status.addStretch()
            vbox.addLayout(hbox_status)

            # Boutons
            btn_on = QPushButton("ON")
            btn_on.clicked.connect(lambda checked, n=nom: self.start_router(n))
            vbox.addWidget(btn_on)

            btn_off = QPushButton("OFF")
            btn_off.clicked.connect(lambda checked, n=nom: self.stop_router(n))
            vbox.addWidget(btn_off)

            frame.setLayout(vbox)
            
            # Ajout grille (5 colonnes)
            row = i // 5
            col = i % 5
            self.grid_layout.addWidget(frame, row, col)

            self.router_widgets[nom] = {
                "lbl_status": lbl_status,
                "port": port
            }

    def save_config_txt(self):
        """Exporte la liste des routeurs pour truc.ps1 (Format: NOM:PORT)"""
        try:
            with open("routers_config.txt", "w") as f:
                # Sort naturally
                keys = sorted(self.g.config_reseau["routers"].keys(), key=lambda x: int(x[1:]) if x[1:].isdigit() else x)
                for nom in keys:
                    port = self.g.config_reseau["routers"][nom]["port"]
                    f.write(f"{nom}:{port}\n")
        except Exception as e:
            print(f"Erreur sauvegarde TXT: {e}")

    def add_router(self):
        nom = self.input_router_name.text().strip()
        port_txt = self.input_router_port.text().strip()
        
        if not nom or not port_txt:
            QMessageBox.warning(self, "Erreur", "Nom et Port requis.")
            return

        try:
            port = int(port_txt)
        except:
            QMessageBox.warning(self, "Erreur", "Le port doit être un nombre.")
            return

        # 1. Vérif Local
        if nom in self.g.config_reseau["routers"]:
            QMessageBox.warning(self, "Erreur", f"Le routeur {nom} existe déjà (local).")
            return
            
        for r in self.g.config_reseau["routers"].values():
            if r["port"] == port:
                QMessageBox.warning(self, "Erreur", f"Le port {port} est déjà utilisé (local).")
                return

        # 2. Vérif BDD (si connecté)
        if self.db_connected:
            try:
                # On checke routeurs existants en base
                cles = self.g.charger_cles_publiques() # {nom: Key}
                if nom in cles:
                     QMessageBox.warning(self, "Erreur", f"Le routeur {nom} existe déjà en BDD.")
                     return
                # On pourrait verifier le port aussi en fetchant tout, mais charger_cles ne rend que les cles
                # Pour l'instant on fait confiance au local + unicité Nom Primary Key en base
            except Exception as e:
                print(f"Warn check BDD: {e}")

        # Ajout
        self.g.config_reseau["routers"][nom] = {"port": port}
        self.refresh_router_grid()
        self.input_router_name.clear()
        self.input_router_port.clear()
        QMessageBox.information(self, "Succès", f"Routeur {nom} ajouté sur port {port}.")

    def delete_router(self):
        nom = self.input_router_name.text().strip()
        if not nom:
            QMessageBox.warning(self, "Erreur", "Entrez le nom du routeur à supprimer.")
            return
            
        if nom not in self.g.config_reseau["routers"]:
            QMessageBox.warning(self, "Erreur", "Ce routeur n'existe pas.")
            return
            
        # Supprimer de la config locale
        del self.g.config_reseau["routers"][nom]
        
        # Supprimer de la BDD si connecté
        if self.db_connected:
            self.g.supprimer_routeur(nom)

        self.refresh_router_grid()
        QMessageBox.information(self, "Succès", f"Routeur {nom} supprimé.") 

    def connect_db(self):
        host = self.input_ip.text().strip() or "127.0.0.1"
        port_txt = self.input_port.text().strip() or "3306"
        
        # Reset state
        self.db_connected = False
        self.btn_connect.setText("Connecter BDD")
        self.btn_connect.setStyleSheet("background-color: #2196F3; color: white; font-weight: bold;")
        self.btn_connect.setDisabled(False)
        self.input_ip.setDisabled(False)
        self.input_port.setDisabled(False)

        try:
            port = int(port_txt)
            self.g.config_bd["host"] = host
            self.g.config_bd["port"] = port
            
            # Test VRAIE connexion (lève exception si échec)
            self.g.tester_connexion()
            
            # Nettoyage automatique (Demande utilisateur)
            self.g.nettoyer_routeurs_inconnus()

            self.db_connected = True
            
            self.btn_connect.setText("Connecté (OK)")
            self.btn_connect.setStyleSheet("background-color: green; color: white;")
            self.btn_connect.setDisabled(True)
            self.input_ip.setDisabled(True)
            self.input_port.setDisabled(True)
            
            QMessageBox.information(self, "Infos", "Connexion BDD réussie.")
            
        except Exception as e:
            self.db_connected = False
            QMessageBox.critical(self, "Erreur", f"Echec connexion BDD: {e}")

    # --- LOGIQUE ---

    def periodic_update(self):
        self.refresh_logs()
        self.refresh_keys()
        self.update_status_ui()

    def refresh_logs(self):
        if not self.db_connected: return
        logs = self.g.lire_logs(limit=100)
        self.table_logs.setRowCount(0) # Clear
        for i, row in enumerate(logs):
            # row: (timestamp, source, msg)
            self.table_logs.insertRow(i)
            if len(row) >= 3:
                self.table_logs.setItem(i, 0, QTableWidgetItem(str(row[0])))
                self.table_logs.setItem(i, 1, QTableWidgetItem(str(row[1])))
                self.table_logs.setItem(i, 2, QTableWidgetItem(str(row[2])))

    def vider_logs(self):
        if not self.db_connected: return
        self.g.vider_logs()
        self.refresh_logs()

    def refresh_keys(self):
        # On affiche TOUS les routeurs de la config, même ceux sans clé
        self.table_keys.setRowCount(0)
        
        cles = {}
        if self.db_connected:
            cles = self.g.charger_cles_publiques()
            
        config = self.g.config_reseau["routers"]
        
        sorted_keys = sorted(config.keys(), key=lambda x: int(x[1:]) if x[1:].isdigit() else x)
        
        for i, nom in enumerate(sorted_keys):
            self.table_keys.insertRow(i)
            
            # Port depuis la config locale (à jour avec les ajouts dynamiques)
            port = config.get(nom, {}).get("port", "?")
            
            if nom in cles:
                cle_str = str(cles[nom].n)[:40] + "..."
            else:
                cle_str = "Pas de clé en BDD (Démarrer routeur)"
            
            self.table_keys.setItem(i, 0, QTableWidgetItem(nom))
            self.table_keys.setItem(i, 1, QTableWidgetItem(str(port)))
            self.table_keys.setItem(i, 2, QTableWidgetItem(cle_str))

    def run_global_script(self):
        try:
            subprocess.Popen("start powershell -ExecutionPolicy Bypass -File truc.ps1", shell=True)
            self.g.ajouter_log("MASTER", "Lancement Script Global (Qt)")
             # Feedback visuel
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Information)
            msg.setText("Script de lancement activé !")
            msg.exec_()
        except Exception as e:
            QMessageBox.critical(self, "Erreur", f"Echec lancement: {e}")

    def start_router(self, nom):
        # On passe l'IP et Port BDD au routeur + LE PORT D'ECOUTE SPECIFIQUE
        db_host = self.input_ip.text().strip() or "127.0.0.1"
        db_port = self.input_port.text().strip() or "3306"
        
        # On recupere le port d'écoute depuis la config (qui contient les ajouts dynamiques)
        listen_port = self.g.config_reseau["routers"].get(nom, {}).get("port", 5000)

        try:
            # R1.py Nom -m IP_BDD:Port_BDD -p LISTEN_PORT
            cmd = f"start python R1.py {nom} -m {db_host}:{db_port} -p {listen_port}"
            subprocess.Popen(cmd, shell=True)
            self.g.ajouter_log("MASTER", f"Start {nom} (Port {listen_port})")
        except Exception as e:
            print(f"Erreur start {nom}: {e}")

    def stop_router(self, nom):
        port = self.g.config_reseau["routers"][nom]["port"]
        try:
            target_ip = "127.0.0.1" # Les routeurs sont locaux
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((target_ip, port))
                s.sendall("CMD|SHUTDOWN".encode())
            self.g.ajouter_log("MASTER", f"Stop {nom}")
        except:
            self.g.ajouter_log("MASTER", f"Stop {nom} (Echec/Déjà off)")

    def check_routers_status(self):
         target_ip = "127.0.0.1"
         threading.Thread(target=self._scan_thread_logic, args=(target_ip,), daemon=True).start()

    def _scan_thread_logic(self, target_ip):
        # Scan parallèle pour éviter le blocage (20 routeurs * 0.3s = 6s sinon !)
        
        temp_results = {}
        lock = threading.Lock()
        threads = []

        def check_one(nom, port):
            is_open = False
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(0.5) # Un peu plus de marge que 0.3
                if s.connect_ex((target_ip, port)) == 0:
                    is_open = True
                s.close()
            except: 
                pass
            
            with lock:
                temp_results[nom] = is_open

        for nom, info in self.router_widgets.items():
            port = info["port"]
            t = threading.Thread(target=check_one, args=(nom, port))
            t.start()
            threads.append(t)
        
        for t in threads:
            t.join()
        
        # Update shared state
        self.router_states = temp_results

    # On ajoute cette méthode au main timer
    def update_status_ui(self):
        if hasattr(self, 'router_states'):
            for nom, is_open in self.router_states.items():
                if nom not in self.router_widgets:
                     # Le widget a peut-être été supprimé entre temps
                     continue
                     
                lbl = self.router_widgets[nom]["lbl_status"]
                if is_open:
                    lbl.setText("ON")
                    lbl.setStyleSheet("background-color: #4CAF50; color: white; border-radius: 3px; padding: 2px;")
                else:
                    lbl.setText("OFF")
                    lbl.setStyleSheet("background-color: #F44336; color: white; border-radius: 3px; padding: 2px;")

    def periodic_update(self):
        self.refresh_logs()
        self.refresh_keys()
        self.update_status_ui()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MasterGUI()
    window.show()
    sys.exit(app.exec_())