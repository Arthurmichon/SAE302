CREATE DATABASE IF NOT EXISTS SAE302;
USE SAE302;

-- Création d'un utilisateur spécifique pour l'application (plus sécurisé que root)
-- Mot de passe : 'onion_pass'
CREATE USER IF NOT EXISTS 'user_onion'@'%' IDENTIFIED BY 'onion_pass';

-- On donne les droits uniquement sur la base du projet
GRANT ALL PRIVILEGES ON SAE302.* TO 'user_onion'@'%';
FLUSH PRIVILEGES;

-- Table Routeurs
CREATE TABLE IF NOT EXISTS routeurs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(20) UNIQUE,
    ip VARCHAR(15),
    port INT,
    cle_publique TEXT
) CHARACTER SET utf8 COLLATE utf8_general_ci;

-- Table Clients
CREATE TABLE IF NOT EXISTS clients (
    nom VARCHAR(20) PRIMARY KEY,
    port INT,
    ip VARCHAR(50) DEFAULT '127.0.0.1'
) CHARACTER SET utf8 COLLATE utf8_general_ci;

-- Table Logs
CREATE TABLE IF NOT EXISTS sys_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    horodatage TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    source VARCHAR(50),
    message TEXT
) CHARACTER SET utf8 COLLATE utf8_general_ci;
