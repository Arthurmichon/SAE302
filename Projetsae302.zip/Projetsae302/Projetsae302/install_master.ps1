Write-Host "Installation des dépendances pour MASTER (Routeurs + Contrôleur)"
Write-Host "================================================================"

# 1. Verification Python
Write-Host "1. Vérification de Python..."
$pythonVersion = python --version 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host "ERREUR : Python n'est pas installé ou pas dans le PATH."
    Write-Host "Veuillez installer Python depuis https://www.python.org/downloads/"
    Write-Host "Cochez la case 'Add Python to PATH' lors de l'installation."
    Pause
    exit
}
Write-Host "   -> Python trouvé : $pythonVersion"

# 2. Mise à jour de PIP
Write-Host "`n2. Mise à jour de PIP..."
python -m pip install --upgrade pip

# 3. Installation des librairies
Write-Host "`n3. Installation des librairies requises..."

$libraries = @(
    "PyQt5",   # Pour l'interface graphique Master.py
    "pymysql", # Pour la connexion BDD (rsa_outils)
    "sympy"    # Pour la génération de clés RSA (rsa_outils)
)

foreach ($lib in $libraries) {
    Write-Host "   -> Installation de $lib..."
    python -m pip install $lib
    if ($LASTEXITCODE -ne 0) {
        Write-Host "      [!] Attention: Erreur lors de l'installation de $lib"
    } else {
        Write-Host "      [OK] $lib installé."
    }
}

Write-Host "`n================================================================"
Write-Host "INSTALLATION TERMINÉE !"
Write-Host "Vous pouvez maintenant lancer :"
Write-Host "  - python Master.py (Interface Contrôleur)"
Write-Host "  - Ou utiliser truc.ps1 pour tout lancer."
Write-Host "================================================================"
Pause
