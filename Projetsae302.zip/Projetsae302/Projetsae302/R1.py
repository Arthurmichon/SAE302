import socket
import sys
import threading
from rsa_outils import GestionCryptoSQL

# Sécurité pour grands nombres (Oignon profond)
try:
    sys.set_int_max_str_digits(100000)
except AttributeError:
    pass # Python < 3.11 n'a pas cette limite

IP = "127.0.0.1"

# ============================================
# Initialisation Crypto + SQL
# ============================================

# ============================================
# Initialisation Crypto + SQL
# ============================================

import argparse

parser = argparse.ArgumentParser(description='Onion Router')
parser.add_argument('nom', nargs='?', default="R1", help='Nom du routeur')
parser.add_argument('-m', '--master', help='IP:Port du Maître/BDD (ex: 192.168.1.10:3306)', default="127.0.0.1:3306")
parser.add_argument('-p', '--port', type=int, help='Port d\'écoute du routeur', default=None)

args = parser.parse_args()

nom_routeur = args.nom

# Parsing Master IP:Port
if ":" in args.master:
    parts = args.master.split(":")
    db_ip = parts[0]
    db_port = int(parts[1])
else:
    db_ip = args.master
    db_port = 3306

g = GestionCryptoSQL()
# MAJ Config BDD reçue du Master
g.config_bd["host"] = db_ip
g.config_bd["port"] = db_port

# Port d'écoute
if args.port:
    port = args.port
else:
    # Fallback config hardcodée ou calculée
    if nom_routeur in g.config_reseau["routers"]:
        port = g.config_reseau["routers"][nom_routeur]["port"]
    else:
        # Cas dynamique
        port = 5000 + int(nom_routeur[1:]) if nom_routeur[1:].isdigit() else 5000

# On initialise uniquement la clé de CE routeur
# (au lieu de tout régénérer et écraser les autres)
g.initialiser_routeur(nom_routeur, port=port)

# Détection IP LAN pour enregistrement BDD
lan_ip = "127.0.0.1"
try:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(("8.8.8.8", 80))
    lan_ip = s.getsockname()[0]
    s.close()
except:
    pass
# Correction : Update IP publique en base
# (initialiser_routeur appelle generer_cles mais ne permet pas de set IP facilement,
# donc on force l'update ici pour être sûr).
cle_privee = g.obtenir_cle_privee(nom_routeur)
n_val = cle_privee.n if cle_privee else 0
# Re-enregistrement avec la bonne IP
g.enregistrer_cle_publique(nom_routeur, n_val, port=port, ip=lan_ip)

LISTEN_IP = "0.0.0.0" # Pour écouter tout le monde

print(f"[{nom_routeur}] Démarré sur port {port}, n={cle_privee.n}")
g.ajouter_log(nom_routeur, f"Démarrage sur port {port}")

# ============================================

# ============================================
# Serveur TCP
# ============================================

serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
serveur.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
serveur.bind((LISTEN_IP, port))
serveur.listen()
print(f"[{nom_routeur}] En écoute...\n")

# ... (rest stays same until parser)
# ============================================
# Format paquet : route|dest|C

# ============================================

def parser_paquet(txt):
    parts = txt.split("|", 2)
    route = parts[0].split(";") if parts[0] else []
    dest = parts[1]
    C = parts[2]
    return route, dest, C

def construire_paquet(route, dest, C):
    return ";".join(route) + "|" + dest + "|" + C

# ============================================
# Dictionnaire pour stocker les clients connectés
# clé = nom_client, valeur = port_client
# ============================================

clients_connectes = {}

# ============================================
# Gestion connexion
# ============================================

def gerer(conn):
    with conn:
        # Lecture en boucle pour récupérer tout le message (peut dépasser 65Ko avec l'oignon)
        chunks = []
        while True:
            chunk = conn.recv(65536)
            if not chunk:
                break
            chunks.append(chunk)
        
        if not chunks:
            return
            
        data = b"".join(chunks)
        texte = data.decode()

        # Cas spécial : enregistrement client (prefixe "CLIENT|nom|port")
        if texte.startswith("CLIENT|"):
            _, nom_client, port_client = texte.split("|")
            clients_connectes[nom_client] = int(port_client)
            print(f"[{nom_routeur}] Client enregistré : {nom_client} sur port {port_client}")
            return

        # Cas spécial : demande d'arrêt global
        if texte == "CMD|SHUTDOWN":
            print(f"[{nom_routeur}] ARRÊT D'URGENCE DEMANDÉ.")
            g.ajouter_log(nom_routeur, "ARRÊT - Commande reçue")
            import os
            os._exit(0)

        # Cas normal : message à router
        route, dest, C = parser_paquet(texte)
        print(f"[{nom_routeur}] Reçu route={route}, C={C}")

        # Déchiffrement
        # On utilise le mode Hybride qui gère le format "EncSeed:CipherInt:Len"
        try:
            clair = cle_privee.dechiffrer_hybride(C)
        except Exception as e:
            print(f"[{nom_routeur}] Erreur déchiffrement : {e}")
            g.ajouter_log(nom_routeur, f"Erreur déchiffrement: {e}")
            return
            
        print(f"[{nom_routeur}] → Déchiffré : '{clair[:50]}...'" if len(clair)>50 else f"[{nom_routeur}] → Déchiffré : '{clair}'")

        # Dernier routeur : envoyer au client
        if len(route) == 1:
            # Recherche IP/Port client dans BD
            client_info = g.obtenir_info_client(dest)
            
            dest_ip = "127.0.0.1"
            port_dest = None

            if client_info:
                dest_ip, port_dest = client_info
            else:
                 # Fallback mémoire locale (peu probable d'être à jour pour l'IP)
                 port_dest = clients_connectes.get(dest)

            if port_dest is None:
                print(f"[{nom_routeur}] ERREUR : Client {dest} introuvable.")
                g.ajouter_log(nom_routeur, f"ERREUR: Client {dest} inconnu")
                return

            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.connect((dest_ip, port_dest))
                    s.sendall(clair.encode())
                print(f"[{nom_routeur}] Message final envoyé à {dest} ({dest_ip}:{port_dest})")
                g.ajouter_log(nom_routeur, f"Message LIVRÉ à {dest}")
            except Exception as e:
                print(f"[{nom_routeur}] ERREUR envoi à {dest} : {e}")
                g.ajouter_log(nom_routeur, f"Erreur livraison {dest}: {e}")
            return

        # Routeur suivant
        next_r = route[1]
        next_route = route[1:]

        # Le payload déchiffré (clair) est déjà chiffré pour le suivant dans l'oignon
        # On ne re-chiffre PAS. On transmet tel quel.
        C_suivant = clair

        paquet = construire_paquet(next_route, dest, C_suivant)

        port_suiv = g.config_reseau["routers"][next_r]["port"]
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                # Récup IP du prochain routeur depuis BDD ou Config
                # Mais config locale master n'a que les ports.
                # Il faut la BDD pour l'IP si multi-PC.
                target_ip = "127.0.0.1"
                # On essaie de choper l'IP en base si dispo
                # (TODO: optimiser pour pas faire de SQL à chaque paquet)
                # ICI on suppose réseau local simple ou tout le monde est sur même IP si pas trouvé.
                # Pour le multi-PC : Il faut lire la table routeurs.
                # On ne l'a pas en cache simple ici. 
                # On va faire une requête rapide.
                try:
                    # Recup IP depuis BDD
                    import pymysql
                    cn = pymysql.connect(**g.config_bd)
                    cr = cn.cursor()
                    cr.execute("SELECT ip FROM routeurs WHERE nom=%s", (next_r,))
                    row = cr.fetchone()
                    if row: target_ip = row[0]
                    cn.close()
                except Exception as e:
                    print(f"[{nom_routeur}] Warn: Echec récup IP pour {next_r}: {e}")

                s.connect((target_ip, port_suiv))
                s.sendall(paquet.encode())
            print(f"[{nom_routeur}] → Transmis à {next_r}")
            g.ajouter_log(nom_routeur, f"Relayé vers {next_r}")
        except Exception as e:
            print(f"[{nom_routeur}] ERREUR envoi à {next_r} : {e}")
            g.ajouter_log(nom_routeur, f"Erreur relais vers {next_r}")

# ============================================
# Boucle principale
# ============================================

try:
    while True:
        conn, _ = serveur.accept()
        threading.Thread(target=gerer, args=(conn,), daemon=True).start()
except Exception as e:
    print(f"ERREUR FATALE R1: {e}")
    import traceback
    traceback.print_exc()
    input("Appuyez sur Entrée pour quitter...")
except KeyboardInterrupt:
    print("Arrêt par utilisateur.")
    input("Appuyez sur Entrée pour quitter...")
