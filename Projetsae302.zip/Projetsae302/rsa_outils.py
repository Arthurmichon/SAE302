import pymysql
from pymysql import Error
import random
import sys

# Augmenter la limite de conversion int<->str pour supporter les gros paquets oignon (20+ couches)
sys.set_int_max_str_digits(100000)


# Mini-RSA simplifié
class MiniRSAKey:
    def __init__(self, e, d, n):
        self.e = e
        self.d = d
        self.n = n

    # chiffrement/déchiffrement d'un texte
    def chiffrer(self, m: int) -> int:
        """Chiffre un entier."""
        return pow(m, self.e, self.n)

    def dechiffrer(self, c: int) -> str:
        """Déchiffre un entier en caractère(s)."""
        M = pow(c, self.d, self.n)
        octets = []
        while M > 0:
            octets.append(M & 0xFF)
            M >>= 8
        return ''.join(chr(b) for b in reversed(octets))

    def chiffrer_hybride(self, texte: str) -> str:
        """
        Chiffrement Hybride Optimisé (RSA + XOR + Base64).
        Empêche l'explosion exponentielle de la taille du message.
        Structure: EncryptedSeed:Base64Cipher
        """
        if not texte: return ""
        import base64 

        # 1. Seed (clé) aléatoire
        seed = random.randint(1, self.n - 1)
        enc_seed = self.chiffrer(seed)

        # 2. Conversion texte -> octets
        # Le texte peut être le résultat d'un chiffrement précédent (donc déjà en base64 partiel)
        msg_bytes = texte.encode('utf-8')
        length = len(msg_bytes)

        # 3. Masque XOR
        rng = random.Random(seed)
        # On génère des octets aléatoires
        # getrandbits génère un entier, on le convertit en bytes
        mask_int = rng.getrandbits(length * 8)
        mask_bytes = mask_int.to_bytes(length, 'big')

        # 4. XOR
        msg_int = int.from_bytes(msg_bytes, 'big')
        cipher_int = msg_int ^ mask_int
        cipher_bytes = cipher_int.to_bytes(length, 'big')

        # 5. Encodage en Base64
        b64_cipher = base64.b64encode(cipher_bytes).decode('ascii')

        return f"{enc_seed}:{b64_cipher}"

    def dechiffrer_hybride(self, packet: str) -> str:
        """Déchiffre un paquet hybride Base64."""
        import base64
        try:
            if not packet: return ""
            parts = packet.split(":")
            
            if len(parts) == 3:
                return self.dechiffrer_hybride_legacy(packet)
            
            if len(parts) != 2:
                 return self.dechiffrer_texte_legacy(packet)

            enc_seed_str, b64_cipher = parts
            enc_seed = int(enc_seed_str)

            # 1. Déchiffrer Seed
            seed = int(pow(enc_seed, self.d, self.n))

            # 2. Decode Base64
            cipher_bytes = base64.b64decode(b64_cipher)
            length = len(cipher_bytes)

            # 3. Masque XOR
            rng = random.Random(seed)
            mask_int = rng.getrandbits(length * 8)
            
            # 4. XOR Inverse
            cipher_int = int.from_bytes(cipher_bytes, 'big')
            msg_int = cipher_int ^ mask_int
            msg_bytes = msg_int.to_bytes(length, 'big')

            return msg_bytes.decode('utf-8')
        except Exception as e:
            # print(f"DEBUG: Echec decrypt '{packet[:20]}...': {e}")
            return "[ERR_DECRYPT]"

    def dechiffrer_hybride_legacy(self, packet):
        try:
            parts = packet.split(":")
            enc_seed, cipher_int, bit_len = int(parts[0]), int(parts[1]), int(parts[2])
            seed = int(pow(enc_seed, self.d, self.n))
            rng = random.Random(seed)
            mask = rng.getrandbits(bit_len)
            msg_int = cipher_int ^ mask
            byte_len = (msg_int.bit_length() + 7) // 8
            if byte_len == 0: return ""
            return msg_int.to_bytes(byte_len, 'big').decode()
        except:
            return "[ERR_LEGACY]"

    def dechiffrer_texte_legacy(self, texte_chiffre: str) -> str:
        if not texte_chiffre.strip(): return ""
        try:
            entiers = [int(x) for x in texte_chiffre.split(",")]
            return "".join(self.dechiffrer(c) for c in entiers)
        except:
            return "[ERR]"
    
    # Alias pour ne pas casser le code existant immédiatement, mais on redirige vers hybride pour les nouveaux chiffrements
    def chiffrer_texte(self, texte: str) -> str:
        return self.chiffrer_hybride(texte)
        
    def dechiffrer_texte(self, texte_chiffre: str) -> str:
        return self.dechiffrer_hybride(texte_chiffre)


class GestionCrypto:
    def __init__(self):
        self.privees = {}
        self.publiques = {}

    def generer_cles(self, nom):
        from sympy import randprime
        # Génération de p et q aléatoires distincts
        p = randprime(1000, 5000)
        q = randprime(1000, 5000)
        while p == q:
            q = randprime(1000, 5000)
            
        n = p * q
        phi = (p-1)*(q-1)
        
        # Choisir e premier avec phi
        e = 65537
        # Si e n'est pas copremier avec phi, on change p et q (simplification)
        # Mais 65537 est généralement ok. Vérifions pgcd.
        import math
        while math.gcd(e, phi) != 1:
             p = randprime(1000, 5000)
             q = randprime(1000, 5000)
             phi = (p-1)*(q-1)

        d = pow(e, -1, phi)
        self.privees[nom] = MiniRSAKey(e=None, d=d, n=n)
        self.publiques[nom] = MiniRSAKey(e=e, d=None, n=n)
        return (e, n), (d, n)

    def obtenir_priv(self, nom):
        return self.privees.get(nom)

    def obtenir_pub(self, nom):
        return self.publiques.get(nom)


# Gestion Crypto + MySQL
class GestionCryptoSQL:
    def __init__(self):
        self.crypto = GestionCrypto()

        self.config_bd = {
            "host": "localhost",
            "user": "user_onion",
            "password": "onion_pass",
            "database": "SAE302",
            "charset": "utf8"
        }

        self.config_reseau = {
            "routers": {f"R{i}": {"port": 5000 + i} for i in range(1, 21)}
        }

    def tester_connexion(self):
        # Tente une connexion et lève une exception si échoue.
        # Copie de la config pour ajouter le timeout sans toucher au reste
        cfg = self.config_bd.copy()
        cfg["connect_timeout"] = 2
        
        # On passe toute la config (host, port, user...)
        conn = pymysql.connect(**cfg)
        conn.ping(reconnect=False)
        conn.close()

    def creer_base_et_table(self):
        """
        Obsolète : La création se fait via install_db.ps1 / setup_db.sql (par peur de tout casser je le laisse)
        """
        pass

    def enregistrer_cle_publique(self, nom_routeur, n_pub, port=None, ip=None):
        try:
            conn = pymysql.connect(**self.config_bd)
            cur = conn.cursor()
            sql = (
                "INSERT INTO routeurs (nom, ip, port, cle_publique) "
                "VALUES (%s,%s,%s,%s) "
                "ON DUPLICATE KEY UPDATE ip=VALUES(ip), port=VALUES(port), cle_publique=VALUES(cle_publique)"
            )
            
            # Si l'IP n'est pas fournie, on essaie de deviner l'IP LAN, sinon 127.0.0.1
            if ip is None:
                ip = "127.0.0.1"
                try:
                    import socket
                    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                    s.connect(("8.8.8.8", 80))
                    ip = s.getsockname()[0]
                    s.close()
                except:
                    pass

            # Si le port n'est pas fourni, on cherche dans la config, sinon 0
            if port is None:
                port = self.config_reseau["routers"].get(nom_routeur, {}).get("port", 0)

            cur.execute(sql, (nom_routeur, ip, port, str(n_pub)))
            conn.commit()
            cur.close()
            conn.close()
        except Exception as e:
            print(f"[BD] Erreur enregistrer_cle_publique : {e}")



    def charger_cles_publiques(self):
        res = {}
        try:
            conn = pymysql.connect(**self.config_bd)
            cur = conn.cursor()
            cur.execute("SELECT nom, cle_publique FROM routeurs")
            for nom, n_raw in cur.fetchall():
                # Gestion compatibilité : si n_raw est au format {'e':..., 'n':...}
                n_val = 0
                n_str = str(n_raw).strip()
                
                if n_str.startswith("{"):
                    # On cherche "n": 123... ou 'n': 123...
                    try:
                        # Nettoyage basique
                        temp = n_str.replace('"', '').replace("'", "").replace("}", "").replace("{", "")
                        # temp ressemble à: e: 65537, n : 12345
                        parts = temp.split(',')
                        for p in parts:
                            kv = p.split(':')
                            if len(kv) == 2:
                                key = kv[0].strip()
                                val = kv[1].strip()
                                if key == 'n':
                                    n_val = int(val)
                                    break
                    except:
                        pass # Echec parsing, on garde 0 ou on erreur plus bas
                else:
                    # Cas normal : juste l'entier stocké en string
                    try:
                        n_val = int(n_str)
                    except:
                        pass
                
                if n_val > 0:
                    res[nom] = MiniRSAKey(e=65537, d=None, n=n_val)
                    
            cur.close()
            conn.close()
        except Exception as e:
            print(f"[BD] Erreur chargement clés publiques : {e}")
        return res

    def generer_toutes_les_cles(self):
        self.creer_base_et_table()
        for nom in self.config_reseau["routers"]:
            print(f"[*] Génération clés {nom}")
            (e, n), (d, _) = self.crypto.generer_cles(nom)
            self.enregistrer_cle_publique(nom, n)
        print("[OK] Toutes les clés générées & stockées en BD")

    def initialiser_routeur(self, nom, port=None):
        self.creer_base_et_table()
        print(f"[*] Génération clé pour {nom}")
        (e, n), (d, _) = self.crypto.generer_cles(nom)
        self.enregistrer_cle_publique(nom, n, port)
        print(f"[OK] Clé {nom} générée & stockée")

    def obtenir_cle_privee(self, nom):
        return self.crypto.obtenir_priv(nom)

    def supprimer_routeur(self, nom):
        try:
            conn = pymysql.connect(**self.config_bd)
            cur = conn.cursor()
            cur.execute("DELETE FROM routeurs WHERE nom=%s", (nom,))
            conn.commit()
            cur.close()
            conn.close()
            print(f"[BD] Routeur {nom} supprimé.")
        except Exception as e:
            print(f"[BD] Erreur suppression routeur {nom} : {e}")

    def nettoyer_routeurs_inconnus(self):
        # Supprime de la BDD les routeurs qui ne sont pas dans la config locale (R1-R20 par défaut)
        try:
            conn = pymysql.connect(**self.config_bd)
            cur = conn.cursor()
            
            # Récupérer tous les noms en BDD
            cur.execute("SELECT nom FROM routeurs")
            noms_bdd = [row[0] for row in cur.fetchall()]
            
            # Comparer avec config locale
            locaux = self.config_reseau["routers"].keys()
            
            for nom in noms_bdd:
                if nom not in locaux:
                    print(f"[BD] Nettoyage : Suppression de {nom} (non utilisé localement)")
                    cur.execute("DELETE FROM routeurs WHERE nom=%s", (nom,))
            
            conn.commit()
            cur.close()
            conn.close()
        except Exception as e:
            print(f"[BD] Erreur nettoyage : {e}")


    # Gestion Clients (Port)
    def enregistrer_client(self, nom_client, port, ip="127.0.0.1"):
        try:
            conn = pymysql.connect(**self.config_bd)
            cur = conn.cursor()
            
            sql = (
                "INSERT INTO clients (nom, port, ip) VALUES (%s, %s, %s) "
                "ON DUPLICATE KEY UPDATE port=VALUES(port), ip=VALUES(ip)"
            )
            cur.execute(sql, (nom_client, port, ip))
            conn.commit()
            cur.close()
            conn.close()
            print(f"[BD] Client {nom_client} enregistré sur {ip}:{port}")
        except Exception as e:
            print(f"[BD] Erreur enregistrement client : {e}")
            raise e

    def obtenir_port_client(self, nom_client):
        info = self.obtenir_info_client(nom_client)
        if info: return info[1]
        return None

    def obtenir_info_client(self, nom_client):
        """Retourne (ip, port) du client"""
        info = None
        try:
            conn = pymysql.connect(**self.config_bd)
            cur = conn.cursor()
            # On vérifie si la colonne IP existe (compatibilité)
            try:
                cur.execute("SELECT ip, port FROM clients WHERE nom=%s", (nom_client,))
                res = cur.fetchone()
                if res:
                    info = (res[0], res[1])
            except:
                # Fallback ancienne table sans IP
                cur.execute("SELECT port FROM clients WHERE nom=%s", (nom_client,))
                res = cur.fetchone()
                if res:
                    info = ("127.0.0.1", res[0])
            
            cur.close()
            conn.close()
        except Exception as e:
            print(f"[BD] Erreur lecture info client : {e}")
        return info


    # Gestion Logs (Système centralisé)
    def ajouter_log(self, source, message):
        # Ajoute un log dans la base de données.
        try:
            conn = pymysql.connect(**self.config_bd)
            cur = conn.cursor()
            sql = "INSERT INTO sys_logs (source, message) VALUES (%s, %s)"
            cur.execute(sql, (source, message))
            conn.commit()
            cur.close()
            conn.close()
        except Exception:
            pass

    def lire_logs(self, limit=50):
        # Récupère les derniers logs
        logs = []
        try:
            conn = pymysql.connect(**self.config_bd)
            cur = conn.cursor()
            cur.execute("SHOW TABLES LIKE 'sys_logs'")
            if cur.fetchone():
                cur.execute("SELECT horodatage, source, message FROM sys_logs ORDER BY id DESC LIMIT %s", (limit,))
                logs = cur.fetchall()
            cur.close()
            conn.close()
        except Exception as e:
            print(f"Erreur lecture logs: {e}")
        return logs
        
    def vider_logs(self):
        try:
            conn = pymysql.connect(**self.config_bd)
            cur = conn.cursor()
            cur.execute("TRUNCATE TABLE sys_logs")
            conn.commit()
            cur.close()
            conn.close()
        except: pass

