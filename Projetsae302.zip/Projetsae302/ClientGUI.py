import sys
import socket
import threading
import random
import time
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
    QLabel, QLineEdit, QPushButton, QTextEdit, QGroupBox, QInputDialog, QMessageBox,
    QTabWidget 
)
from PyQt5.QtCore import pyqtSignal, QObject
from rsa_outils import GestionCryptoSQL

# Signal worker pour les updates GUI depuis le thread socket
class ClientWorker(QObject):
    msg_received = pyqtSignal(str)

class ClientGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Client Onion Routing")
        self.resize(600, 700)
        
        # Crypto & Config
        self.g = GestionCryptoSQL()
        self.worker = ClientWorker()
        self.worker.msg_received.connect(self.append_log)
        
        self.server_socket = None
        self.listening = False

        # --- UI LAYOUT ---
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        
        # 1. Configuration Réseau
        group_config = QGroupBox("Configuration Réseau")
        form_layout = QVBoxLayout()
        
        # Ligne 1 : Nom et IP
        h1 = QHBoxLayout()
        self.input_client_name = QLineEdit("Client1")
        
        # Detecte automatiquement l'IP
        my_lan_ip = "127.0.0.1"
        try:
            s_ip = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s_ip.connect(("8.8.8.8", 80))
            my_lan_ip = s_ip.getsockname()[0]
            s_ip.close()
        except: pass

        self.input_client_ip = QLineEdit(my_lan_ip)
        h1.addWidget(QLabel("Nom Unique:"))
        h1.addWidget(self.input_client_name)
        h1.addWidget(QLabel("Mon IP LAN:"))
        h1.addWidget(self.input_client_ip)
        form_layout.addLayout(h1)

        # Ligne 2 : Port et Master (IP + Port de la BDD)
        h2 = QHBoxLayout()
        self.input_client_port = QLineEdit("4001")
        self.input_master_ip = QLineEdit("127.0.0.1")
        self.input_master_port = QLineEdit("3306")
        
        h2.addWidget(QLabel("Mon Port:"))
        h2.addWidget(self.input_client_port)
        h2.addWidget(QLabel("IP BDD (Master):"))
        h2.addWidget(self.input_master_ip)
        h2.addWidget(QLabel("Port BD:"))
        h2.addWidget(self.input_master_port)
        form_layout.addLayout(h2)

        # Bouton Connexion
        self.btn_connect = QPushButton("Démarrer Client / S'enregistrer")
        self.btn_connect.setStyleSheet("background-color: #2196F3; color: white; font-weight: bold;")
        self.btn_connect.clicked.connect(self.start_client)
        form_layout.addWidget(self.btn_connect)
        
        group_config.setLayout(form_layout)
        layout.addWidget(group_config)

        # 2. Zone Message
        group_msg = QGroupBox("Envoi Message")
        msg_layout = QVBoxLayout()
        
        # Route
        h_route = QHBoxLayout()
        h_route.addWidget(QLabel("Route (ex: R1,R2 ou 'random'):"))
        self.input_route = QLineEdit("random")
        h_route.addWidget(self.input_route)
        msg_layout.addLayout(h_route)
        
        # Message
        self.input_msg = QTextEdit()
        self.input_msg.setPlaceholderText("Votre message ici...")
        self.input_msg.setFixedHeight(100)
        msg_layout.addWidget(self.input_msg)
        
        # Zone d'envoi (Target + Bouton)
        h_send = QHBoxLayout()
        h_send.addWidget(QLabel("Destinataire :"))
        self.input_target = QLineEdit()
        self.input_target.setPlaceholderText("ex: Client_4002")
        h_send.addWidget(self.input_target)
        
        self.btn_send = QPushButton("Envoyer")
        self.btn_send.setStyleSheet("background-color: #4CAF50; color: white; font-weight: bold;")
        self.btn_send.clicked.connect(self.send_message)
        self.btn_send.setEnabled(False) # Activé après start
        h_send.addWidget(self.btn_send)
        
        msg_layout.addLayout(h_send)
        
        group_msg.setLayout(msg_layout)
        layout.addWidget(group_msg)

        # 3. Zone de réception (Chate & Logs)
        group_rx = QGroupBox("Réception")
        rx_layout = QVBoxLayout()
        
        self.tabs_rx = QTabWidget()
        
        # Tab du Chate
        self.tab_chat = QWidget()
        layout_chat = QVBoxLayout(self.tab_chat)
        self.text_chat = QTextEdit()
        self.text_chat.setReadOnly(True)
        self.text_chat.setStyleSheet("font-size: 14px; background-color: #f0f0f0;")
        layout_chat.addWidget(self.text_chat)
        self.tabs_rx.addTab(self.tab_chat, "💬 Discussion")
        
        # Tab des Logs
        self.tab_logs = QWidget()
        layout_logs = QVBoxLayout(self.tab_logs)
        self.text_logs = QTextEdit()
        self.text_logs.setReadOnly(True)
        self.text_logs.setStyleSheet("font-family: Consolas; font-size: 10px;")
        layout_logs.addWidget(self.text_logs)
        self.tabs_rx.addTab(self.tab_logs, "🛠 Logs Techniques") # Logs techniques séparés
        
        rx_layout.addWidget(self.tabs_rx)
        group_rx.setLayout(rx_layout)
        layout.addWidget(group_rx)

    def append_log(self, text):
        # On filtre : si c'est un message [REÇU], on le met dans le chat
        if "[REÇU]" in text:
            clean_msg = text.replace("[REÇU] ", "")
            # Timestamp simple
            import datetime
            ts = datetime.datetime.now().strftime("%H:%M:%S")
            # Format chat
            self.text_chat.append(f"<div style='margin: 5px; padding: 5px; background-color: white; border: 1px solid #ddd; border-radius: 5px;'><b>[{ts}] Reçu:</b><br>{clean_msg}</div>")
            # On focus l'onglet chat
            self.tabs_rx.setCurrentIndex(0)
            
        # Dans tous les cas on met dans les logs techniques
        self.text_logs.append(text)

    def append_chat(self, author, message):
        import datetime
        ts = datetime.datetime.now().strftime("%H:%M:%S")
        color = "#e3f2fd" if author == "Moi" else "#ffffff"
        align = "right" if author == "Moi" else "left"
        
        # Style simplifié pour Qt
        html = f"""
        <div style='background-color: {color}; margin: 2px; padding: 4px;'>
            <b>[{ts}] {author}:</b><br>{message}
        </div>
        """
        self.text_chat.append(html)
        # Scroll to bottom ?? handled by append usually
        self.tab_chat.setFocus() # Pour voir le messsage ? Non, juste switch tab.
        # Mais on veut switcher l'onglet actif.
        self.tabs_rx.setCurrentIndex(0) # 0 = Chat

    def start_client(self):
        try:
            # 1. Validation des champs
            try:
                my_ip = self.input_client_ip.text().strip()
                my_port = int(self.input_client_port.text())
                name = self.input_client_name.text().strip()
                master_ip = self.input_master_ip.text().strip()
                master_port = int(self.input_master_port.text().strip())
                
                if not name: name = f"Client_{my_port}"
                self.nom_client = name
            except ValueError:
                QMessageBox.critical(self, "Erreur Format", "Les ports doivent être des nombres entiers.")
                return 

            # 2. Configuration BDD
            self.g.config_bd["host"] = master_ip
            self.g.config_bd["port"] = master_port

            # 3. Test Connexion BDD et Enregistrement
            try:
                # On teste d'abord la co
                self.g.tester_connexion()
                # Si ok, on enregistre
                self.g.enregistrer_client(self.nom_client, my_port, ip=my_ip)
                self.append_log(f"[*] Enregistré en BD : {self.nom_client} @ {my_ip}:{my_port}")
            except Exception as e:
                self.append_log(f"[!] Erreur BD: {e}")
                QMessageBox.critical(self, "Erreur Connexion BDD", 
                                     f"Impossible de joindre la base de données ({master_ip}:{master_port}).\n\n"
                                     f"Détail : {e}\n\n"
                                     "Vérifiez l'adresse IP du Master, le port, et que le serveur SQL tourne.")
                return # ON ARRÊTE LA, bouton reste activé pour correction

            # 4. Démarrage du Serveur écoute
            if not self.listening:
                try:
                    self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    self.server_socket.bind(("0.0.0.0", my_port)) # Bind local
                    self.server_socket.listen()
                    self.listening = True
                    threading.Thread(target=self.listen_loop, daemon=True).start()
                    self.append_log(f"[*] Serveur écoute sur {my_ip}:{my_port}")
                except Exception as e:
                    self.append_log(f"[!] Erreur Port Local: {e}")
                    QMessageBox.critical(self, "Erreur Port", 
                                     f"Impossible d'ouvrir le port local {my_port}.\n"
                                     f"Il est peut-être déjà utilisé par une autre application.\n\n"
                                     f"Erreur : {e}")
                    return # ON ARRÊTE LA

            # 5. Tout est OK -> On gèle l'interface
            self.btn_send.setEnabled(True)
            self.btn_connect.setEnabled(False)
            self.input_client_ip.setEnabled(False)
            self.input_client_port.setEnabled(False)
            self.input_master_ip.setEnabled(False)
            self.input_master_port.setEnabled(False)
            self.input_client_name.setEnabled(False)
            
        except Exception as e:
            QMessageBox.critical(self, "Erreur Inattendue", f"Une erreur imprévue est survenue : {e}")
            self.append_log(f"[!] CRASH: {e}")

    def listen_loop(self):
        while self.listening:
            try:
                conn, addr = self.server_socket.accept()
                threading.Thread(target=self.handle_connection, args=(conn,), daemon=True).start()
            except:
                break
    
    def handle_connection(self, conn):
        try:
            with conn:
                chunks = []
                while True:
                    chunk = conn.recv(65536)
                    if not chunk: break
                    chunks.append(chunk)
                if chunks:
                    msg = b"".join(chunks).decode(errors='ignore')
                    self.worker.msg_received.emit(f"[REÇU] {msg}")
        except Exception as e:
            print(e)

    def send_message(self):
        route_str = self.input_route.text().strip()
        msg = self.input_msg.toPlainText()
        
        if not msg:
            return

        # 1. Déterminer la route
        # Cela permet de voir R21, R22... s'ils ont été ajoutés, au lieu de rester jusqu'à R20
        try:
            cles_db = self.g.charger_cles_publiques()
            if cles_db:
                tous_routeurs = list(cles_db.keys())
            else:
                 tous_routeurs = list(self.g.config_reseau["routers"].keys())
        except:
             tous_routeurs = list(self.g.config_reseau["routers"].keys())

        # On retrie pour faire propre (ex: R1, R2... R10)
        tous_routeurs.sort(key=lambda x: int(x[1:]) if x[1:].isdigit() else x)
        
        final_route = []
        
        if route_str.lower() == "random":
            # Filtrage des routeurs ACTIFS SEULEMENT
            print("Test des routeurs actifs...")
            self.append_log("[*] Scan des routeurs actifs pour Random...")
            routeurs_actifs = []
            
            # Pour l'UI ne pas geler, idéalement faudrait un thread, mais ici on fait simple/rapide
            # On va tester rapidement la connexion TCP
            for r_nom in tous_routeurs:
                try:
                    # Trouver port/Ip
                    port = None
                    ip = "127.0.0.1" # Defaut
                    
                    # Check config locale
                    if r_nom in self.g.config_reseau["routers"]:
                        port = self.g.config_reseau["routers"][r_nom]["port"]
                    
                    # Check BDD si besoin (pour dynamique) ou pour IP
                    # (Note: ici on pourrait optimiser en chargeant tout d'un coup, mais bon)
                    if not port or r_nom not in self.g.config_reseau["routers"]:
                         pass

                    # Test connexion rapide
                    if port:
                        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        sock.settimeout(0.1) 
                        # Ici on teste en localhost par defaut ou IP Master si c'est R1..R20 fixes
                        if sock.connect_ex((self.input_master_ip.text(), port)) == 0:
                            routeurs_actifs.append(r_nom)
                        sock.close()
                except:
                    pass
            
            self.append_log(f"[*] Routeurs actifs trouvés : {len(routeurs_actifs)} ({', '.join(routeurs_actifs)})")
            
            if not routeurs_actifs:
                 QMessageBox.warning(self, "Erreur", "Aucun routeur actif trouvé !")
                 return

            # Demander le nombre
            nb_dispo = len(routeurs_actifs)
            nb, ok = QInputDialog.getInt(self, "Random Route", 
                                        f"Nombre de routeurs (max {nb_dispo}) ?", 
                                        value=min(3, nb_dispo), min=1, max=nb_dispo)
            if ok:
                final_route = random.sample(routeurs_actifs, nb)
                self.append_log(f"-> Route Random générée : {final_route}")
            else:
                return # Annulé
        else:
            final_route = [r.strip() for r in route_str.split(",") if r.strip()]
        
        if not final_route:
            self.append_log("[!] Route vide !")
            return

        target = self.input_target.text().strip()
        if not target:
            QMessageBox.warning(self, "Attention", "Veuillez entrer un destinataire.")
            return

        # 2. Construction Oignon
        try:
            # On charge les clés à jour
            cles_pub = self.g.charger_cles_publiques()

            
            master_ip = self.input_master_ip.text()

            # Le message clair est le msg utilisateur.
            curr_msg = msg
            
            # Le destinataire final pour le dernier routeur est 'target'
            next_dest = target 
            
            full_route_list = list(final_route) # [R1, R2]
            
            payload = msg
            current_dest = target # La cible finale
            
            # On parcourt la route à lenvers
            # i va de len-1 à 0
            for i in range(len(full_route_list)-1, -1, -1):
                r_nom = full_route_list[i]
                route_segment = full_route_list[i:]
                route_str_segment = ",".join(route_segment)
                
                cle_pub = cles_pub[r_nom]

                if i == len(full_route_list) - 1:

                    # Ici payload est le message clair.
                    encrypted_payload = cle_pub.chiffrer_hybride(payload)
                    
                    # Le paquet pour CE routeur (le dernier) sera construit plus bas.
                    # Mais le "payload" qui deviendra le C de la couche précédente est ce encrypted_payload.
                    payload = encrypted_payload
                    current_dest = target # Pour le dernier, le champ dest est la target finale
                else:
                    # Routeur intermédiaire                    
                    encrypted_payload = cle_pub.chiffrer_hybride(payload)
                    payload = encrypted_payload
                    current_dest = target 

            # A la fin de la boucle, `payload` est le message super-chiffré.

            full_route_str = ";".join(full_route_list)
            packet_str = f"{full_route_str}|{target}|{payload}"
            
            # Envoi au premier routeur
            first_router = full_route_list[0]
            port_first = self.g.config_reseau["routers"][first_router]["port"]
            
            self.append_log(f"-> Tentative connexion à {first_router} ({master_ip}:{port_first}) ...")

            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                # Recup IP first router depuis BDD si possible
                dest_r_ip = master_ip # Par defaut master si local

                try:
                     import pymysql
                     cn = pymysql.connect(**self.g.config_bd)
                     cr = cn.cursor()
                     cr.execute("SELECT ip FROM routeurs WHERE nom=%s", (first_router,))
                     rw = cr.fetchone()
                     if rw: dest_r_ip = rw[0]
                     cn.close()
                except: pass
                
                s.settimeout(5.0) # Timeout plus long (5s)
                s.connect((dest_r_ip, port_first))
                s.sendall(packet_str.encode())
            
            self.append_log(f"-> Envoyé à {first_router} (Cible: {target})")
            
            # Feedback Chat seulement si pas d'exception
            self.append_chat("Moi", msg)
            self.input_msg.clear()
            
        except ConnectionRefusedError:
            QMessageBox.critical(self, "Erreur Connexion", 
                                 f"Impossible de se connecter au routeur {first_router} ({port_first}).\n\n"
                                 "Vérifiez que :\n"
                                 "1. Le Master a bien lancé les routeurs (tout est vert ?)\n"
                                 "2. L'IP du Master est correcte.")
            self.append_log(f"[!] CONNEXION REFUSÉE par {first_router}")
        except Exception as e:
            self.append_log(f"[!] Erreur Envoi: {e}")
            import traceback
            traceback.print_exc()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ClientGUI()
    window.show()
    sys.exit(app.exec_())
